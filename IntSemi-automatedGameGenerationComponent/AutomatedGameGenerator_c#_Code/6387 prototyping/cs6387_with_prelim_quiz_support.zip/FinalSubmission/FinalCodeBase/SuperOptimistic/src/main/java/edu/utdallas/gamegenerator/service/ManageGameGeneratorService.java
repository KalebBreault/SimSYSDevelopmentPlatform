package edu.utdallas.gamegenerator.service;

import edu.utdallas.gamegenerator.model.GameGeneratorInfo;

/**
 * @author Divya
 * 
 */
public interface ManageGameGeneratorService {

    /**
     * 
     * @param gameGeneratorInfo        
     */
    void generateXML(GameGeneratorInfo gameGeneratorInfo);

}

package edu.utdallas.gamegenerator.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import edu.utdallas.gamegenerator.constants.ApplicationConstants;
import edu.utdallas.gamegenerator.constants.ScreenType;
import edu.utdallas.gamegenerator.model.Act;
import edu.utdallas.gamegenerator.model.GameGeneratorInfo;
import edu.utdallas.gamegenerator.model.QuestionInfo;
import edu.utdallas.gamegenerator.model.Scene;
import edu.utdallas.gamegenerator.model.Screen;

/**
 * 
 * @author Siva
 * 
 */
public final class ManageGameElementConfigHelper {

    private static final String SCREENCONFIG_METH = "From getScreenCountConfig :";

    private static final Logger LOG = Logger
            .getLogger(ManageGameElementConfigHelper.class);

    /**
 * 
 */
    private ManageGameElementConfigHelper() {

    }

    /**
     * 
     * Populate the GameGenInfo's screen with the configured screen.
     * 
     * @param selectedScreen   
     * @param screen1   
     */
    public static void populateScreenWithConfig(final Screen selectedScreen,
            final Screen screen1) {
        final String transistionType = selectedScreen.getTransistionType();
        if (null != transistionType && !"".equals(transistionType)) {
            if ("fixedtime".equalsIgnoreCase(transistionType)) {
                screen1.setFixedTimeTransistion(selectedScreen
                        .getFixedTimeTransistion());
                screen1.setUserControlledTransistion(null);
            } else if ("usercontime".equalsIgnoreCase(transistionType)) {
                screen1.setUserControlledTransistion(selectedScreen
                        .getUserControlledTransistion());
                screen1.setFixedTimeTransistion(null);
            } else {
                screen1.setFixedTimeTransistion(null);
                screen1.setUserControlledTransistion(null);
            }

        }

        if (selectedScreen.isPropsCheck()) {
            screen1.setPropList(Utility.removeUnSelectedProp(selectedScreen
                    .getPropList()));
        } else {
            screen1.setPropList(null);
        }
        if (selectedScreen.isNpcCheck()) {
            screen1.setNonPlayingCharList(Utility
                    .removeUnSelectedProp(selectedScreen
                            .getNonPlayingCharList()));
        } else {
            screen1.setNonPlayingCharList(null);
        }
        if (selectedScreen.isButtonsCheck()) {
            screen1.setButtonList(Utility.removeUnSelectedProp(selectedScreen
                    .getButtonList()));
        } else {
            screen1.setButtonList(null);
        }
        if (selectedScreen.isQuestionsCheck()) {
            screen1.setDifficultySetting(selectedScreen.getDifficultySetting());
            screen1.setNoOfQuestions(selectedScreen.getNoOfQuestions());
            screen1.setQuestionLocation(selectedScreen.getQuestionLocation());
        } else {
            screen1.setDifficultySetting(null);
            screen1.setNoOfQuestions(null);
            screen1.setQuestionLocation(null);
        }

        if (selectedScreen.isAnimationCharCheck()) {
            screen1.setAnimCharacter(selectedScreen.getAnimCharacter());
        } else {
            screen1.setAnimCharacter(null);
        }
        if (null != selectedScreen.getInformBox()
                && selectedScreen.getInformBox().isCheckId()) {
            screen1.setInformBox(selectedScreen.getInformBox());
        } else {
            screen1.setInformBox(null);
        }
        
        if (null != selectedScreen.getScore() && !"".equalsIgnoreCase(selectedScreen.getScore().trim()))
        {
            screen1.setScore(selectedScreen.getScore());
        }
    }

    /**
     * This method adds the configured screen to the existing GameGenerator Info
     * 
     * @param selectedScreen    
     * @param session   
     * @param curGameGenInfo   
     * @return curGameGenInfo   
     */
    public static GameGeneratorInfo addScreenConfigToGameGenInfo(
            final Screen selectedScreen, final HttpSession session,
            GameGeneratorInfo curGameGenInfo) {
        if (null != selectedScreen) {
            final String selectedScreenId = selectedScreen.getScreenId();
            LOG.info(SCREENCONFIG_METH + selectedScreenId);
            final String[] idArr = selectedScreenId.split("_");
            final String currentActId = idArr[0];
            final String currentSceneId = idArr[0] + "_" + idArr[1];

            if (null == curGameGenInfo) {
                curGameGenInfo = new GameGeneratorInfo();
                final Act act = new Act(currentActId, currentActId);
                final Scene scene1 = new Scene(currentSceneId, idArr[1]);
                final List<Act> actList = new ArrayList<Act>();
                final List<Scene> sceneList = new ArrayList<Scene>();
                final List<Screen> screenList = new ArrayList<Screen>();
                final Screen screen1 = new Screen(selectedScreenId, idArr[2]);
                populateScreenWithConfig(selectedScreen, screen1);
                populateQuestionList(session, screen1);
                screenList.add(screen1);
                scene1.setScreenList(screenList);
                sceneList.add(scene1);
                act.setSceneList(sceneList);
                actList.add(act);
                curGameGenInfo.setActList(actList);
                session.setAttribute(ApplicationConstants.GAME_GEN_INFO,
                        curGameGenInfo);

            } else {
                final List<Act> actList = curGameGenInfo.getActList();
                if (null != actList && !actList.isEmpty()) {
                    for (Act act : actList) {
                        if (act.getActId().equalsIgnoreCase(currentActId)) {
                            for (Scene currentScene : act.getSceneList()) {
                                if (currentScene.getSceneId().equalsIgnoreCase(
                                        currentSceneId)) {
                                    for (Screen screen1 : currentScene
                                            .getScreenList()) {
                                        if (screen1.getScreenId()
                                                .equalsIgnoreCase(
                                                        selectedScreenId)) {
                                            populateScreenWithConfig(
                                                    selectedScreen, screen1);
                                            populateQuestionList(session,
                                                    screen1);
                                            screen1.setConfigured(true);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }
        }
        return curGameGenInfo;
    }

    /**
     * 
     * @param session   
     * @param screen1   
     */
    private static void populateQuestionList(HttpSession session, Screen screen1) {

        if (null != screen1) {
            Map<String, List<QuestionInfo>> selectedQuestionsmap = (Map<String, List<QuestionInfo>>) session
                    .getAttribute("selectedQuestionsmap");
            if (null != selectedQuestionsmap && selectedQuestionsmap.size() > 0) {
                List<QuestionInfo> questionList = selectedQuestionsmap
                        .get(screen1.getScreenId());
                if (null != questionList && questionList.size() > 0) {
                    screen1.setQuestionList(questionList);
                    session.setAttribute("selectedQuestionsmap", null);
                }
            }
        }
    }

    /**
     * This method adds the configured screen to the existing GameGenerator Info
     * 
     * @param selectedScreen   
     * @param session   
     * @param curGameGenInfo  
     * @param screenType   
     * @return curGameGenInfo   
     */
    public static GameGeneratorInfo addConfiguredScreenToGameGenInfo(
            final Screen selectedScreen, final HttpSession session,
            GameGeneratorInfo curGameGenInfo, final String screenType) {
        if (null != selectedScreen) {
            final String selectedScreenId = selectedScreen.getScreenId();
            LOG.info(SCREENCONFIG_METH + selectedScreenId);
            final String[] idArr = selectedScreenId.split("_");
            final String currentActId = idArr[0];
            final String currentSceneId = idArr[0] + "_" + idArr[1];

            if (null == curGameGenInfo) {
                curGameGenInfo = new GameGeneratorInfo();
                final Act act = new Act(currentActId, currentActId);
                final Scene scene1 = new Scene(currentSceneId, idArr[1]);
                final List<Act> actList = new ArrayList<Act>();
                final List<Scene> sceneList = new ArrayList<Scene>();
                final List<Screen> screenList = new ArrayList<Screen>();
                final Screen screen1 = new Screen(selectedScreenId, idArr[2]);
                screen1.setScreenType(ScreenType.DIFFICULTYLEVEL.toString());
                screen1.setDifficultySetting(selectedScreen
                        .getDifficultySetting());
                screenList.add(screen1);
                scene1.setScreenList(screenList);
                sceneList.add(scene1);
                act.setSceneList(sceneList);
                actList.add(act);
                curGameGenInfo.setActList(actList);
                session.setAttribute(ApplicationConstants.GAME_GEN_INFO,
                        curGameGenInfo);
            } else {

                final List<Act> actList = curGameGenInfo.getActList();
                if (null != actList && !actList.isEmpty()) {
                    for (Act act : actList) {
                        if (act.getActId().equalsIgnoreCase(currentActId)) {
                            for (Scene currentScene : act.getSceneList()) {
                                if (currentScene.getSceneId().equalsIgnoreCase(
                                        currentSceneId)) {
                                    for (Screen screen1 : currentScene
                                            .getScreenList()) {
                                        if (screen1.getScreenId()
                                                .equalsIgnoreCase(
                                                        selectedScreenId)
                                                && null != screenType
                                                && !"".equals(screenType.trim())) {
                                            // if(null != screenType &&
                                            // !"".equals(screenType.trim()))
                                            // {
                                            screen1.setScreenType(screenType);
                                            if (screenType
                                                    .equalsIgnoreCase(ScreenType.DIFFICULTYLEVEL
                                                            .toString())) {
                                                screen1.setDifficultySetting(selectedScreen
                                                        .getDifficultySetting());
                                            } else if (screenType
                                                    .equalsIgnoreCase(ScreenType.NOOFQUESTIONS
                                                            .toString())) {
                                                screen1.setNoOfQuestions(selectedScreen
                                                        .getNoOfQuestions());
                                                screen1.setQuestionLocation(selectedScreen
                                                        .getQuestionLocation());
                                                // chooseRandomQuestionSelection(screen1);
                                            }

                                            // }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }
        }
        return curGameGenInfo;
    }

    /**
     * This method retrieves the screen with neccessary configuration details
     * 
     * @param selectedScreen   
     * @param screen   
     * @param curGameGenInfo   
     * @param screenType   
     * @param session   
     * 
     * @return screen  
     */
    public static Screen getScreenForConfig(final Screen selectedScreen,
            Screen screen, final GameGeneratorInfo curGameGenInfo,
            final String screenType, final HttpSession session) {
        if (null != selectedScreen) {
            final String selectedScreenId = selectedScreen.getScreenId();
            LOG.info(SCREENCONFIG_METH + selectedScreenId);
            final String[] idArr = selectedScreenId.split("_");
            final String currentActId = idArr[0];
            final String currentSceneId = idArr[1];

            if (null != curGameGenInfo) {
                final List<Act> actList = curGameGenInfo.getActList();
                if (null != actList && !actList.isEmpty()) {
                    for (Act act : actList) {
                        if (act.getActId().equalsIgnoreCase(currentActId)) {
                            for (Scene currentScene : act.getSceneList()) {
                                if (currentScene.getSceneId().equalsIgnoreCase(
                                        currentActId + "_" + currentSceneId)) {
                                    for (Screen currentScreen : currentScene
                                            .getScreenList()) {
                                        if (currentScreen.getScreenId()
                                                .equalsIgnoreCase(
                                                        selectedScreenId)) {
                                            currentScreen
                                                    .setScreenType(screenType);
                                            act.setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
                                            currentScene
                                                    .setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
                                            currentScreen
                                                    .setDefaultStyle(ApplicationConstants.DEFAULT_STYLE);
                                            screen = currentScreen;
                                        } else {
                                            currentScreen.setDefaultStyle(null);
                                        }
                                    }
                                } else {
                                    currentScene.setDefaultStyle(null);
                                }
                            }
                        } else {
                            act.setDefaultStyle(null);
                        }
                    }
                }
            }
        }
        if (null == screen) {
            screen = new Screen();
            screen.setScreenType(screenType);
        }
        session.setAttribute(ApplicationConstants.GAME_GEN_INFO, curGameGenInfo);
        return screen;
    }

    /**
     * 
     * This method populates the Scene object with configuration details
     * 
     * @param scene  
     * @param gameGeneratorInfo   
     * @param screenList   
     * @param sceneId   
     * @param currentActId  
     * @param noOfScreens  
     * @return gameGeneratorInfo  
     */
    public static GameGeneratorInfo populateSceneWithConfigDetails(
            final Scene scene, GameGeneratorInfo gameGeneratorInfo,
            final List<Screen> screenList, final String sceneId,
            final String currentActId, final int noOfScreens) {
        List<Scene> sceneList;
        if (null != currentActId && !"".equals(currentActId.trim())) {
            if (null == gameGeneratorInfo) {
                gameGeneratorInfo = new GameGeneratorInfo();
                final Act act = new Act(currentActId, currentActId);
                final Scene scene1 = new Scene(scene.getSceneId(),
                        scene.getSceneName());
                final List<Act> actList = new ArrayList<Act>();
                sceneList = new ArrayList<Scene>();
                scene1.setScreenList(screenList);
                sceneList.add(scene1);
                act.setSceneList(sceneList);
                actList.add(act);
                gameGeneratorInfo.setActList(actList);
            } else {
                final List<Act> actList = gameGeneratorInfo.getActList();
                for (Act act : actList) {
                    if (act.getActId().equalsIgnoreCase(currentActId)) {
                        sceneList = act.getSceneList();
                        for (Scene currentScene : sceneList) {
                            if (currentScene.getSceneId().equalsIgnoreCase(
                                    sceneId)) {
                                currentScene.setBackdrop(scene.getBackdrop());
                                currentScene.setNoOfScreens(noOfScreens);
                                currentScene.setScreenList(screenList);
                            }
                        }
                    }
                }
            }
        }
        return gameGeneratorInfo;
    }

    /**
     * 
     * This method populates the Act object with coniguration details from view
     * 
     * @param act   
     * @param gameGeneratorInfo   
     * @param sceneList   
     * @param noOfScenes  
     * @return ModelAndView   
     */
    public static GameGeneratorInfo populateActWithConfigDetails(final Act act,
            GameGeneratorInfo gameGeneratorInfo, final List<Scene> sceneList,
            final int noOfScenes) {
        if (null == gameGeneratorInfo) {
            gameGeneratorInfo = new GameGeneratorInfo();
            final List<Act> actList = new ArrayList<Act>();
            act.setSceneList(sceneList);
            actList.add(act);
            gameGeneratorInfo.setActList(actList);
        } else {
            final List<Act> actList = gameGeneratorInfo.getActList();
            for (Act act2 : actList) {
                if (act2.getActId().equalsIgnoreCase(act.getActId())) {
                    act2.setNoOfScenes(noOfScenes);
                    act2.setSceneList(sceneList);
                }
            }
        }
        return gameGeneratorInfo;
    }

}

package edu.utdallas.gamegenerator.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.utdallas.gamegenerator.constants.ApplicationConstants;
import edu.utdallas.gamegenerator.model.GameGeneratorInfo;
import edu.utdallas.gamegenerator.model.UserProfileConfiguration;
import edu.utdallas.gamegenerator.service.ManageGameGeneratorService;

/**
 * @author Meyy
 * 
 */
@Controller
public class ManageUserProfileController {

    private static final String USER_PROFILE = "userProfileConfiguration";

    private static final String SEL_PLAY_CHAR = "selectedPlayerCharacters";

    private static final String PLAYER_CHARACTERS = "Player Characters";

    private static final Logger LOG = Logger
            .getLogger(ManageUserProfileController.class);

    private transient ManageGameGeneratorService manageGameGenServ;

    /**
     * 
     * This method redirects the control to homepage
     * 
     * @param request   
     * @param session   
     * @param model  
     * @param session1  
     * 
     * @return ModelAndView   
     */
    @RequestMapping(value = "/gameGen.htm", method = RequestMethod.GET)
    public final ModelAndView manageHomePage(final HttpServletRequest request,
            final HttpSession session, final ModelMap model,
            final HttpSession session1) {
        return new ModelAndView("welcomepage");
    }

    /**
     * 
     * This method redirects the control to user page
     * 
     * @param request  
     * @param session  
     * @param model   
     * @param session1  
     * @return ModelAndView   
     */
    @RequestMapping(value = "/userProfile.htm", method = RequestMethod.GET)
    public final ModelAndView manageUserProfile(
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        return new ModelAndView("/UserProfile/homepage");
    }

    /**
     * 
     * This method redirects the control to configure user profile screen
     * 
     * @param request   
     * @param session   
     * @param model  
     * @param session1  
     * @return ModelAndView   
     */
    @RequestMapping(value = "/configureProfile.htm", method = RequestMethod.GET)
    public final ModelAndView configureUserProfile(
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model, final HttpSession session1) {
        GameGeneratorInfo currGameGenInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        UserProfileConfiguration userProfileConfig = (UserProfileConfiguration) session
                .getAttribute(USER_PROFILE);
        if (null == currGameGenInfo) {
            currGameGenInfo = new GameGeneratorInfo();
        }
        if (null == userProfileConfig) {
            userProfileConfig = new UserProfileConfiguration();
        }
        currGameGenInfo.setUserProfileConfiguration(userProfileConfig);
        return new ModelAndView("/UserProfile/customprofile",
                "UserProfileConfiguration", userProfileConfig);
    }

    /**
     * 
     * This method fetches existing player characters from game asset repository
     * and displays it on the page
     * 
     * 
     * @param request  
     * @param session   
     * @param model  
     * @return ModelAndView    
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/selectProfile.htm", method = RequestMethod.GET)
    public final ModelAndView selectUserProfile(
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model) {
        Map<String, String> fileList = (Map<String, String>) session
                .getAttribute("playerCharacters");
        if (null == fileList) {
            final File folder = new File(
                    "C:\\Users\\Meyy\\Downloads\\GameAssetRepository\\GameAssetRepository"
                            + "\\Office, Classroom\\Visual\\Characters\\Player Characters");
            fileList = new HashMap<String, String>();
            try {
                listFilesForFolder(folder, fileList, true);
            } catch (IOException e) {
                LOG.error("IO Exception while accesing game asset repository",
                        e);
            }
            if (!fileList.isEmpty()) {
                session.setAttribute("playerCharacters", fileList);
            }
        }
        return new ModelAndView("/UserProfile/existingprofiles");
    }

    /**
     * 
     * This method displays the summary page of selected player characters
     * before submission
     * 
     * 
     * @param request   
     * @param session  
     * @param model  
     * @return ModelAndView   
     */
    @RequestMapping(value = "/selectProfile.htm", method = RequestMethod.POST)
    public final ModelAndView submitPlayerCharProfile(
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model) {
        session.setAttribute(SEL_PLAY_CHAR, null);
        final String strSelProfiles = request.getParameter("selectedProfiles");
        if (null != strSelProfiles && !"".equals(strSelProfiles.trim())) {
            final String[] selProfiles = strSelProfiles.split(":");
            List<String> existingPlayChar;
            if (selProfiles.length > 0) {
                existingPlayChar = new ArrayList<String>();
                for (String profile : selProfiles) {
                    existingPlayChar.add(profile);
                }
                session.setAttribute(SEL_PLAY_CHAR, existingPlayChar);
            }
        }
        return new ModelAndView("/UserProfile/playerCharacterSummary");
    }

    /**
     * 
     * This method submits the selected player characters and generates XML
     * 
     * @param request   
     * @param session  
     * @param model  
     * @return ModelAndView   
     */
    @RequestMapping(value = "/submitPlayerCharProfile.htm", method = RequestMethod.POST)
    public final ModelAndView submitPreSelectedProfile(
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model) {

        final List<String> selPlayersList = (List<String>) session
                .getAttribute(SEL_PLAY_CHAR);
        GameGeneratorInfo gameGeneratorInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        if (null == gameGeneratorInfo) {
            gameGeneratorInfo = new GameGeneratorInfo();
        }
        if (null != selPlayersList && !selPlayersList.isEmpty()) {
            final UserProfileConfiguration userProfile1 = new UserProfileConfiguration();
            userProfile1.setExistingPlayerCharacter(selPlayersList);
            gameGeneratorInfo.setUserProfileConfiguration(userProfile1);
            // manageGameGeneratorService.generateXML(gameGeneratorInfo);

        }
        session.setAttribute(SEL_PLAY_CHAR, null);
        session.setAttribute(USER_PROFILE, null);
        session.setAttribute(ApplicationConstants.GAME_GEN_INFO,
                gameGeneratorInfo);
        return new ModelAndView("/UserProfile/profileConfirmationPage");

    }

    /**
     * This method displays the skip profile page
     * 
     * @param request  
     * @param session  
     * @param model   
     * @param session1  
     * @return ModelAndView   
     */
    @RequestMapping(value = "/noProfile.htm", method = RequestMethod.GET)
    public final ModelAndView noProfile(final HttpServletRequest request,
            final HttpSession session, final ModelMap model,
            final HttpSession session1) {
        return new ModelAndView("/UserProfile/skipprofile");
    }

    /**
     * 
     * This method retrieves the user profile configuration from the view and
     * displays the summary page
     * 
     * @param userProfile   
     * @param request  
     * @param session  
     * @param model  
     * @return ModelAndView   
     */

    @RequestMapping(value = "/configureProfile.htm", method = RequestMethod.POST)
    public final ModelAndView submitUserProfileConfig(
            @ModelAttribute("UserProfileConfiguration") final UserProfileConfiguration userProfile,
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model) {
        LOG.info("Name : " + userProfile.isName());
        LOG.info("Full Name : " + userProfile.isFullName());
        LOG.info("Nick Name : " + userProfile.isNickName());
        LOG.info("Age : " + userProfile.isAge());
        LOG.info("Country : " + userProfile.isCountry());
        LOG.info("Profile Picture : " + userProfile.isProfilePicture());
        LOG.info("Language Preference  : " + userProfile.isLanguagePreference());

        // manageUserProfileService.generateXML(userProfileConfiguration);
        session.setAttribute(USER_PROFILE, userProfile);

        return new ModelAndView("/UserProfile/profilesummary");
    }

    /**
     * This method retrieves the user profile configuration from the view and
     * generates the game engine input xml
     * 
     * @param request   
     * @param session  
     * @param model  
     * @return ModelAndView   
     */
    @RequestMapping(value = "/confirmProfileConfig.htm", method = RequestMethod.POST)
    public final ModelAndView confirmUserProfileConfig(
            final HttpServletRequest request, final HttpSession session,
            final ModelMap model) {
        LOG.info("Inside confirmUserProfileConfig method!!");
        final UserProfileConfiguration userProfile2 = (UserProfileConfiguration) session
                .getAttribute(USER_PROFILE);
        GameGeneratorInfo gameGeneratorInfo = (GameGeneratorInfo) session
                .getAttribute(ApplicationConstants.GAME_GEN_INFO);
        if (null == gameGeneratorInfo) {
            gameGeneratorInfo = new GameGeneratorInfo();
        }

        if (null != userProfile2) {
            gameGeneratorInfo.setUserProfileConfiguration(userProfile2);
            // manageGameGeneratorService.generateXML(gameGeneratorInfo);
        }
        session.setAttribute(USER_PROFILE, null);
        session.setAttribute(ApplicationConstants.GAME_GEN_INFO,
                gameGeneratorInfo);
        return new ModelAndView("/UserProfile/profileConfirmationPage");
    }

    /**
     * 
     * This method retrieves the player character details from the game asset
     * repository
     * 
     * @param folder  
     * @param fileList  
     * @param flag   
     * @throws IOException   
     */

    public static void listFilesForFolder(final File folder,
            final Map<String, String> fileList, final boolean flag)
            throws IOException {

        String parentFolderName;
        for (final File fileEntry : folder.listFiles()) {
            if (fileEntry.isDirectory()) {
                if (flag) {
                    LOG.info(fileEntry.getName());
                    fileList.put(fileEntry.getName(), null);
                    parentFolderName = fileEntry.getParentFile().getName();
                    if (parentFolderName.equalsIgnoreCase(PLAYER_CHARACTERS)) {
                        listFilesForFolder(fileEntry, fileList, false);
                    }
                }
            } else {
                LOG.info(fileEntry.getName());
                final String absolutePath = fileEntry.getAbsolutePath()
                        .replaceAll("\\\\", "/");
                fileList.put(fileEntry.getParentFile().getName(), absolutePath);
                break;
            }
        }
    }

    /**
     * @return the manageGameGeneratorService  
     */
    public final ManageGameGeneratorService getManageGameGeneratorService() {
        return manageGameGenServ;
    }

    /**
     * @param manageGameGen1   
     *            the manageGameGeneratorService to set
     */
    public final void setManageGameGeneratorService(
            final ManageGameGeneratorService manageGameGen1) {
        this.manageGameGenServ = manageGameGen1;
    }

}

package edu.utdallas.gamegenerator.constants;

/**
 * 
 * @author Meyy
 * 
 */
public enum ScreenType {

    DIFFICULTYLEVEL, NOOFQUESTIONS, LISTOFQUESTIONS;

}

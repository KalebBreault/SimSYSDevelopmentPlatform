package edu.utdallas.gamegenerator.model;

import javax.xml.bind.annotation.XmlElement;

/**
 * 
 * @author Preethi
 * 
 */
public class ScreenTransistion {

    private String animationType;
    private String transistionTime;

    /**
     * @return the animationType
     */
    public final String getAnimationType() {
        return animationType;
    }

    /**
     * @param animationType1
     *            the animationType to set
     */
    @XmlElement
    public final void setAnimationType(final String animationType1) {
        this.animationType = animationType1;
    }

    /**
     * @return the transistionTime
     */
    public final String getTransistionTime() {
        return transistionTime;
    }

    /**
     * @param transistionTime1
     *            the transistionTime to set
     */
    @XmlElement
    public final void setTransistionTime(final String transistionTime1) {
        this.transistionTime = transistionTime;
    }

}

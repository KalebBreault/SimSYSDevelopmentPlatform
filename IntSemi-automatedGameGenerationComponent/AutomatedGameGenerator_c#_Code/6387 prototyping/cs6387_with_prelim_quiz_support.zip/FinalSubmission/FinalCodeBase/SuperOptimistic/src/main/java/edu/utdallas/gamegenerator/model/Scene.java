package edu.utdallas.gamegenerator.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 * 
 * @author Preethi
 * 
 */
public class Scene {

    private String sceneName;
    private String sceneId;
    private String backdrop;
    private List<Screen> screenList;
    private int noOfScreens;
    private String defaultStyle = "";

    /**
     */
    public Scene() {
        super();
    }

    /**
     * 
     * @param sceneId1   
     * @param sceneName1   
     */
    public Scene(final String sceneId1, final String sceneName1) {
        super();
        this.sceneId = sceneId1;
        this.sceneName = sceneName1;
    }

    /**
     * @return the backdrop
     */
    public final String getBackdrop() {
        return backdrop;
    }

    /**
     * @param backdrop1
     *            the backdrop to set
     */
    @XmlElement(name = "Backdrop")
    public final void setBackdrop(final String backdrop1) {
        this.backdrop = backdrop1;
    }

    /**
     * @return the screenList
     */
    public final List<Screen> getScreenList() {
        return screenList;
    }

    /**
     * @param screenList1
     *            the screenList to set
     */
    @XmlElement(name = "screen")
    public final void setScreenList(final List<Screen> screenList1) {
        this.screenList = screenList1;
    }

    /**
     * @return the sceneId
     */
    public final String getSceneId() {
        return sceneId;
    }

    /**
     * @param sceneId1
     *            the sceneId to set
     */
    @XmlTransient
    public final void setSceneId(final String sceneId1) {
        this.sceneId = sceneId1;
    }

    /**
     * @return the sceneName
     */
    public final String getSceneName() {
        return sceneName;
    }

    /**
     * @param sceneName1
     *            the sceneName to set
     */
    public final void setSceneName(final String sceneName1) {
        this.sceneName = sceneName1;
    }

    /**
     * @return the noOfScreens
     */
    public final int getNoOfScreens() {
        return noOfScreens;
    }

    /**
     * @param noOfScreens1
     *            the noOfScreens to set
     */
    public final void setNoOfScreens(final int noOfScreens1) {
        this.noOfScreens = noOfScreens1;
    }

    /**
     * @return the defaultStyle
     */
    public final String getDefaultStyle() {
        return defaultStyle;
    }

    /**
     * @param defaultStyle1
     *            the defaultStyle to set
     */
    @XmlTransient
    public final void setDefaultStyle(final String defaultStyle1) {
        this.defaultStyle = defaultStyle1;
    }

}

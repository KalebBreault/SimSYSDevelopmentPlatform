package edu.utdallas.gamegenerator.constants;

/**
 * 
 * @author Meyy
 * 
 */
public final class ApplicationConstants {
/**
 * 
 */
    private ApplicationConstants() {
        super();
    }

    public static final String DEFAULT_STYLE = "jstree-open";
    public static final String GAME_GEN_INFO = "GameGeneratorInfo";

}

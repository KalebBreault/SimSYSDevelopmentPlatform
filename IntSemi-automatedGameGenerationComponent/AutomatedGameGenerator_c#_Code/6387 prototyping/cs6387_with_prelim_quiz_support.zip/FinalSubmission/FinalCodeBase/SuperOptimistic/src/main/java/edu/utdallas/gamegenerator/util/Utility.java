package edu.utdallas.gamegenerator.util;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

import edu.utdallas.gamegenerator.model.Act;
import edu.utdallas.gamegenerator.model.Prop;
import edu.utdallas.gamegenerator.model.QuestionInfo;
import edu.utdallas.gamegenerator.model.Questions;
import edu.utdallas.gamegenerator.model.Scene;
import edu.utdallas.gamegenerator.model.Screen;

/**
 * 
 * @author Siva
 * 
 */
public final class Utility {

    /**
     * constructor
     */
    private Utility() {
        super();
    }

    private static final Logger LOG = Logger.getLogger(Utility.class);

    /**
     * 
     * This method returns Act list to calling method
     * 
     * @return actList
     */
    public static List<Act> populateAct() {
        final List<Act> actList = new ArrayList<Act>();

        for (int i = 1; i <= 2; i++) {
            actList.add(populateActDetails("act" + i, "Act" + i));
        }

        LOG.info(actList);

        return actList;

    }

    /**
     * This method populates the Act info object with id and title
     * 
     * @param actId   
     * @param actTitle     
     * @return act1     
     */
    private static Act populateActDetails(final String actId,
            final String actTitle) {
        final Act act1 = new Act(actId, actTitle);
        final List<Scene> sceneList = new ArrayList<Scene>();
        for (int i = 1; i <= 2; i++) {
            sceneList.add(populateSceneDetails("scene" + i, "Scene" + i));
        }
        act1.setSceneList(sceneList);

        return act1;
    }

    /**
     * 
     * This method populates the scene info object with id and title
     * 
     * @param sceneId     
     * @param sceneTitle      
     * @return scene     
     */
    private static Scene populateSceneDetails(final String sceneId,
            final String sceneTitle) {
        final List<Screen> screenList = new ArrayList<Screen>();
        final Scene scene = new Scene(sceneId, sceneTitle);
        for (int i = 1; i <= 2; i++) {
            screenList.add(populateScreenDetails("screen" + i, "Screen" + i));
        }
        scene.setScreenList(screenList);

        return scene;
    }

    /**
     * This method populates the screen info object with id, title and
     * questionid
     * 
     * @param screenId  
     * @param screenTitle  
     * 
     * @return screen
     */
    private static Screen populateScreenDetails(final String screenId,
            final String screenTitle) {
        final Screen screen = new Screen(screenId, screenTitle);
        // QuestionInfo question = new QuestionInfo(questionId);
        // Prop button = new Prop();
        // screen.setQuestion(question);
        // screen.setButton(button);
        return screen;
    }

    /**
     * 
     * This method poulates the prop
     * 
     * @return propList
     */
    public static List<Prop> populatePropList() {
        final List<Prop> propList = new ArrayList<Prop>();

        propList.add(populateProp("chair", false, "chair.jpg",
                "images/chair.jpg", null));
        propList.add(populateProp("table", false, "table.jpg",
                "images/table.jpg", null));
        // propList.add(populateProp("television",false,"television.jpg","images/television.jpg",null));
        LOG.info(propList);

        return propList;

    }

    /**
     * 
     * @param tdName   
     * @param checkId   
     * @param propName   
     * @param propPath  
     * @param propPosition  
     * 
     * @return prop
     */
    private static Prop populateProp(final String tdName,
            final boolean checkId, final String propName,
            final String propPath, final String propPosition) {
        final Prop prop = new Prop();
        prop.setTdName(tdName);
        prop.setCheckId(checkId);
        prop.setPropName(propName);
        prop.setPropPath(propPath);
        prop.setPropPosition(propPosition);
        return prop;
    }

    /**
     * 
     * @param propList    
     * 
     * @return selectedPropList
     */
    public static List<Prop> removeUnSelectedProp(final List<Prop> propList) {
        final List<Prop> selectedPropList = new ArrayList<Prop>();
        for (final Iterator<Prop> iterator = propList.iterator(); iterator
                .hasNext();) {
            final Prop prop = (Prop) iterator.next();
            LOG.info("Is prop checked :" + prop.isCheckId());
            if (prop.isCheckId()) {
                selectedPropList.add(prop);
            }
        }

        return selectedPropList;
    }

    /**
     * 
     * This method poulates the prop
     * 
     * @return npList
     */
    public static List<Prop> populateNPList() {
        final List<Prop> npList = new ArrayList<Prop>();

        npList.add(populateProp("np1", false, "NP1.png", "images/NP1.png", null));
        npList.add(populateProp("np2", false, "NP2.png", "images/NP2.png", null));
        npList.add(populateProp("np3", false, "NP3.png", "images/NP3.png", null));
        LOG.info(npList);

        return npList;

    }

    /**
     * 
     * This method poulates the prop
     * 
     * @return buttonList
     */
    public static List<Prop> populateButtonList() {
        final List<Prop> buttonList = new ArrayList<Prop>();

        buttonList.add(populateProp("button1", false, "button1.png",
                "images/button1.png", null));
        buttonList.add(populateProp("button2", false, "button2.png",
                "images/button2.png", null));
        buttonList.add(populateProp("button3", false, "button3.png",
                "images/button3.jpg", null));
        LOG.info(buttonList);

        return buttonList;

    }

    /**
     * 
     * @return questionlist    
     * @throws Exception   
     *      
     * 
     */
    public static List<QuestionInfo> getQuestionsList() throws Exception {
        JAXBContext jc = JAXBContext.newInstance(Questions.class);

        Unmarshaller unmarshaller = jc.createUnmarshaller();
        File xml = new File("C:\\Users\\Meyy\\Documents\\Questions.xml");
        Questions questions = (Questions) unmarshaller.unmarshal(xml);
        if (null != questions && null != questions.getQuestionList()
                && questions.getQuestionList().size() > 0) {
            return questions.getQuestionList();
        }

        return null;

    }

}

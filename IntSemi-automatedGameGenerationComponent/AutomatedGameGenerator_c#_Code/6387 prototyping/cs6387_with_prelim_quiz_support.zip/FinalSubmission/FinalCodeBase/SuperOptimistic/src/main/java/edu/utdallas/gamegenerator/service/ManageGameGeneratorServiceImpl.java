package edu.utdallas.gamegenerator.service;

import java.io.File;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.log4j.Logger;

import edu.utdallas.gamegenerator.model.GameGeneratorInfo;

/**
 * @author Divya
 * 
 */
public class ManageGameGeneratorServiceImpl implements
        ManageGameGeneratorService {

    private static final String XML_PATH = "C:\\Users\\Meyy\\Downloads\\GameEngineInput.xml";

    private static final Logger LOG = Logger
            .getLogger(ManageGameGeneratorServiceImpl.class);

    /**
     * 
     * @param gameGeneratorInfo
     * 
     *            This method generates an xml by marshalling the
     *            GameGeneratorInfo object
     * 
     */
    public final void generateXML(final GameGeneratorInfo gameGeneratorInfo) {
        if (null != gameGeneratorInfo) {
            try {
                final File file = new File(XML_PATH);
                if (file.exists()) {
                    file.createNewFile();
                }
                final JAXBContext jaxbContext = JAXBContext
                        .newInstance(GameGeneratorInfo.class);
                final Marshaller jaxbMarshaller = jaxbContext
                        .createMarshaller();

                // output pretty printed
                jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
                        true);

                jaxbMarshaller.marshal(gameGeneratorInfo, file);
                jaxbMarshaller.marshal(gameGeneratorInfo, System.out);

            } catch (JAXBException e) {
                LOG.error("Error while marshalling GameGeneratorInfo", e);
            } catch (IOException e) {
                LOG.error("IO Exception", e);
            }
        }

    }

}

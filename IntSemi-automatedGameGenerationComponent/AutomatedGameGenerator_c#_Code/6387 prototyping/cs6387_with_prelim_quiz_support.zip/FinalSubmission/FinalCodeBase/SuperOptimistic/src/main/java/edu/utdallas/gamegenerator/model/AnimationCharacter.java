package edu.utdallas.gamegenerator.model;

import javax.xml.bind.annotation.XmlElement;

/**
 * 
 * @author Naveen
 * 
 */
public class AnimationCharacter {
    private String image1;
    private String image2;
    private String startingPoint;
    private String endPoint;
    private String animationType;
    private String animationMovTime;
    private String animationEffTime;

    /**
     * @return the image1
     */
    public final String getImage1() {
        return image1;
    }

    /**
     * @param strImage1
     *            the image1 to set
     */
    @XmlElement
    public final void setImage1(String strImage1) {
        this.image1 = strImage1;
    }

    /**
     * @return the image2
     */
    public final String getImage2() {
        return image2;
    }

    /**
     * @param strImage2
     *            the image2 to set
     */
    @XmlElement
    public final void setImage2(String strImage2) {
        this.image2 = strImage2;
    }

    /**
     * @return the startingPoint
     */
    public final String getStartingPoint() {
        return startingPoint;
    }

    /**
     * @param startingPoint1
     *            the startingPoint to set
     */
    @XmlElement
    public final void setStartingPoint(String startingPoint1) {
        this.startingPoint = startingPoint1;
    }

    /**
     * @return the endPoint
     */
    public final String getEndPoint() {
        return endPoint;
    }

    /**
     * @param endPoint1
     *            the endPoint to set
     */
    @XmlElement
    public final void setEndPoint(String endPoint1) {
        this.endPoint = endPoint1;
    }

    /**
     * @return the animationType
     */
    public final String getAnimationType() {
        return animationType;
    }

    /**
     * @param animationType1
     *            the animationType to set
     */
    @XmlElement
    public final void setAnimationType(String animationType1) {
        this.animationType = animationType1;
    }

    /**
     * @return the animationMovTime
     */
    public final String getAnimationMovTime() {
        return animationMovTime;
    }

    /**
     * @param animationMovTime1
     *            the animationMovTime to set
     */
    public final void setAnimationMovTime(String animationMovTime1) {
        this.animationMovTime = animationMovTime1;
    }

    /**
     * @return the animationEffTime
     */
    public final String getAnimationEffTime() {
        return animationEffTime;
    }

    /**
     * @param animationEffTime1
     *            the animationEffTime to set
     */
    public final void setAnimationEffTime(String animationEffTime1) {
        this.animationEffTime = animationEffTime1;
    }

}

package edu.utdallas.gamegenerator.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 * 
 * @author Preethi
 * 
 */
public class Screen {
    /**
     * Default Constructor
     */
    public Screen() {
        super();
    }

    private String screenName;
    private String screenId;
    private List<QuestionInfo> questionList;
    private String screenType;
    private String noOfQuestions;
    private String difficultySetting;
    private String questionLocation;
    private String defaultStyle = "";
    private transient FixedTimeTransistion fTimeTransistion;
    private transient UserControlledTransistion userContrTrans;
    private List<Prop> propList;
    private transient List<Prop> nonPlayCharList;
    private List<Prop> buttonList;
    private boolean questionsCheck;
    private boolean propsCheck;
    private boolean npcCheck;
    private boolean buttonsCheck;
    private String transistionType;
    private transient boolean isConfig;
    private boolean animationCharCheck;
    private AnimationCharacter animCharacter;
    private Prop informBox;
    private String score;
    
    /**
     * 
     * @param screenId1   
     * @param screenName1   
     */
    public Screen(final String screenId1, final String screenName1) {
        super();
        this.screenId = screenId1;
        this.screenName = screenName1;
    }

    /**
     * @return the screenName
     */
    public final String getScreenName() {
        return screenName;
    }

    /**
     * @param screenName1
     *            the screenName to set
     */
    public final void setScreenName(final String screenName1) {
        this.screenName = screenName1;
    }

    /**
     * @return the screenId
     */
    public final String getScreenId() {
        return screenId;
    }

    /**
     * @param screenId1
     *            the screenId to set
     */
    @XmlTransient
    public final void setScreenId(final String screenId1) {
        this.screenId = screenId1;
    }

    /**
     * @return the screenType
     */
    public final String getScreenType() {
        return screenType;
    }

    /**
     * @param screenType1
     *            the screenType to set
     */
    @XmlTransient
    public final void setScreenType(final String screenType1) {
        this.screenType = screenType1;
    }

    /**
     * @return the noOfQuestions
     */
    public final String getNoOfQuestions() {
        return noOfQuestions;
    }

    /**
     * @param noOfQuestions1
     *            the noOfQuestions to set
     */
    public final void setNoOfQuestions(final String noOfQuestions1) {
        this.noOfQuestions = noOfQuestions1;
    }

    /**
     * @return the difficultySetting
     */
    public final String getDifficultySetting() {
        return difficultySetting;
    }

    /**
     * @param diffSetting1
     *            the difficultySetting to set
     */
    @XmlElement
    public final void setDifficultySetting(final String diffSetting1) {
        this.difficultySetting = diffSetting1;
    }

    /**
     * @return the questionList
     */
    public final List<QuestionInfo> getQuestionList() {
        return questionList;
    }

    /**
     * @param questionList1
     *            the questionList to set
     */
    @XmlElement(name = "Question")
    public final void setQuestionList(final List<QuestionInfo> questionList1) {
        this.questionList = questionList1;
    }

    /**
     * @return the questionLocation
     */
    public final String getQuestionLocation() {
        return questionLocation;
    }

    /**
     * @param questionLocation1
     *            the questionLocation to set
     */
    @XmlElement
    public final void setQuestionLocation(final String questionLocation1) {
        this.questionLocation = questionLocation1;
    }

    /**
     * @return the defaultStyle
     */
    public final String getDefaultStyle() {
        return defaultStyle;
    }

    /**
     * @param defaultStyle1
     *            the defaultStyle to set
     */
    @XmlTransient
    public final void setDefaultStyle(final String defaultStyle1) {
        this.defaultStyle = defaultStyle1;
    }

    /**
     * @return the userControlledTransistion
     */
    public final UserControlledTransistion getUserControlledTransistion() {
        return userContrTrans;
    }

    /**
     * @param userContrTrans1
     *            the userControlledTransistion to set
     */
    @XmlElement
    public final void setUserControlledTransistion(
            final UserControlledTransistion userContrTrans1) {
        this.userContrTrans = userContrTrans1;
    }

    /**
     * @return the fixedTimeTransistion
     */
    public final FixedTimeTransistion getFixedTimeTransistion() {
        return fTimeTransistion;
    }

    /**
     * @param fTimeTransistion1
     *            the fixedTimeTransistion to set
     */
    @XmlElement
    public final void setFixedTimeTransistion(
            final FixedTimeTransistion fTimeTransistion1) {
        this.fTimeTransistion = fTimeTransistion1;
    }

    /**
     * @return the propList
     */
    public final List<Prop> getPropList() {
        return propList;
    }

    /**
     * @param propList1
     *            the propList to set
     */
    @XmlElement(name = "prop")
    public final void setPropList(final List<Prop> propList1) {
        this.propList = propList1;
    }

    /**
     * @return the nonPlayingCharList
     */
    public final List<Prop> getNonPlayingCharList() {
        return nonPlayCharList;
    }

    /**
     * @param nonPlayCharList1
     *            the nonPlayingCharList to set
     */
    @XmlElement(name = "NonPlayingCharacter")
    public final void setNonPlayingCharList(final List<Prop> nonPlayCharList1) {
        this.nonPlayCharList = nonPlayCharList1;
    }

    /**
     * @return the buttonList
     */
    public final List<Prop> getButtonList() {
        return buttonList;
    }

    /**
     * @param buttonList1
     *            the buttonList to set
     */
    @XmlElement(name = "Button")
    public final void setButtonList(final List<Prop> buttonList1) {
        this.buttonList = buttonList1;
    }

    /**
     * @return the questionsCheck
     */
    public final boolean isQuestionsCheck() {
        return questionsCheck;
    }

    /**
     * @param questionsCheck1
     *            the questionsCheck to set
     */
    @XmlTransient
    public final void setQuestionsCheck(final boolean questionsCheck1) {
        this.questionsCheck = questionsCheck1;
    }

    /**
     * @return the propsCheck
     */
    public final boolean isPropsCheck() {
        return propsCheck;
    }

    /**
     * @param propsCheck1
     *            the propsCheck to set
     */
    @XmlTransient
    public final void setPropsCheck(final boolean propsCheck1) {
        this.propsCheck = propsCheck1;
    }

    /**
     * @return the npcCheck
     */
    public final boolean isNpcCheck() {
        return npcCheck;
    }

    /**
     * @param npcCheck1
     *            the npcCheck to set
     */
    @XmlTransient
    public final void setNpcCheck(final boolean npcCheck1) {
        this.npcCheck = npcCheck1;
    }

    /**
     * @return the buttonsCheck
     */
    public final boolean isButtonsCheck() {
        return buttonsCheck;
    }

    /**
     * @param buttonsCheck1
     *            the buttonsCheck to set
     */
    @XmlTransient
    public final void setButtonsCheck(final boolean buttonsCheck1) {
        this.buttonsCheck = buttonsCheck1;
    }

    /**
     * @return the transistionType
     */
    public final String getTransistionType() {
        return transistionType;
    }

    /**
     * @param transistionType1
     *            the transistionType to set
     */
    @XmlTransient
    public final void setTransistionType(final String transistionType1) {
        this.transistionType = transistionType1;
    }

    /**
     * @return the isConfigured
     */
    public final boolean isConfigured() {
        return isConfig;
    }

    /**
     * @param isConfig1
     *            the isConfigured to set
     */
    @XmlTransient
    public final void setConfigured(final boolean isConfig1) {
        this.isConfig = isConfig1;
    }

    /**
     * @return the animationCharCheck
     */
    public final boolean isAnimationCharCheck() {
        return animationCharCheck;
    }

    /**
     * @param animationCharCheck1
     *            the animationCharCheck to set
     */
    @XmlTransient
    public final void setAnimationCharCheck(boolean animationCharCheck1) {
        this.animationCharCheck = animationCharCheck1;
    }

    /**
     * @return the animCharacter
     */
    public final AnimationCharacter getAnimCharacter() {
        return animCharacter;
    }

    /**
     * @param animCharacter1
     *            the animCharacter to set
     */

    public final void setAnimCharacter(AnimationCharacter animCharacter1) {
        this.animCharacter = animCharacter1;
    }

    /**
     * @return the informBox
     */
    public final Prop getInformBox() {
        return informBox;
    }

    /**
     * @param informBox1
     *            the informBox to set
     */
    public final void setInformBox(Prop informBox1) {
        this.informBox = informBox1;
    }

    /**
     * @return the score
     */
    public final String getScore() {
        return score;
    }

    /**
     * @param score1 the score to set   
     */
    public final void setScore(String score1) {
        this.score = score1;
    }

}

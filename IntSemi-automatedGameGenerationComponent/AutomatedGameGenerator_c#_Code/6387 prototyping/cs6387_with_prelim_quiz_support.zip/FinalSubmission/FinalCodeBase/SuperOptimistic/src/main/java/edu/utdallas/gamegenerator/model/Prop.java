package edu.utdallas.gamegenerator.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 * 
 * @author Naveen
 * 
 */
public class Prop {

    private String typeName;
    private String name;
    private String location;
    private String size;
    private String tdName;
    private boolean checkId;
    private String propName;
    private String propPath;
    private String propPosition;

    /**
     * @return the typeName
     */

    public final String getTypeName() {
        return typeName;
    }

    /**
     * @param typeName1
     *            the typeName to set
     */
    @XmlTransient
    public final void setTypeName(final String typeName1) {
        this.typeName = typeName1;
    }

    /**
     * @return the name
     */
    public final String getName() {
        return name;
    }

    /**
     * @param name1
     *            the name to set
     */
    @XmlElement
    public final void setName(final String name1) {
        this.name = name1;
    }

    /**
     * @return the location
     */
    public final String getLocation() {
        return location;
    }

    /**
     * @param location1
     *            the location to set
     */
    @XmlTransient
    public final void setLocation(final String location1) {
        this.location = location1;
    }

    /**
     * @return the size
     */
    public final String getSize() {
        return size;
    }

    /**
     * @param size1
     *            the size to set
     */
    @XmlTransient
    public final void setSize(final String size1) {
        this.size = size1;
    }

    /**
     * @return the tdName
     */
    public final String getTdName() {
        return tdName;
    }

    /**
     * @param tdName1
     *            the tdName to set
     */
    @XmlTransient
    public final void setTdName(final String tdName1) {
        this.tdName = tdName1;
    }

    /**
     * @return the propName
     */
    public final String getPropName() {
        return propName;
    }

    /**
     * @param propName1
     *            the propName to set
     */
    @XmlElement
    public final void setPropName(final String propName1) {
        this.propName = propName1;
    }

    /**
     * @return the propPath
     */
    public final String getPropPath() {
        return propPath;
    }

    /**
     * @param propPath1
     *            the propPath to set
     */
    @XmlTransient
    public final void setPropPath(final String propPath1) {
        this.propPath = propPath1;
    }

    /**
     * @return the propPosition
     */
    public final String getPropPosition() {
        return propPosition;
    }

    /**
     * @param propPosition1
     *            the propPosition to set
     */
    @XmlElement
    public final void setPropPosition(final String propPosition1) {
        this.propPosition = propPosition1;
    }

    /**
     * @return the checkId
     */
    public final boolean isCheckId() {
        return checkId;
    }

    /**
     * @param checkId1
     *            the checkId to set
     */
    @XmlTransient
    public final void setCheckId(final boolean checkId1) {
        this.checkId = checkId1;
    }

}

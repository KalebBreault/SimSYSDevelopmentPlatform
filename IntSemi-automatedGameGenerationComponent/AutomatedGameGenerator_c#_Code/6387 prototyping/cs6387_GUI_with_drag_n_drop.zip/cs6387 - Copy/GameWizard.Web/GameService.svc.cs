﻿using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Web;
using GameWizardModel;

namespace GameWizard.Web
{
    [ServiceContract(Namespace = "")]
    [SilverlightFaultBehavior]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class GameService
    {
        #region Game Operations

        [OperationContract]
        public List<GameType> GetGameTypes()
        {
            return new List<GameType>
                {
                    new GameType {Id = 1, Name = "Quiz"},
                    new GameType {Id = 2, Name = "Narrative"}
                };
        }

        [OperationContract]
        public List<Subject> GetSubjects()
        {
            var subjects = new List<Subject>
                {
                    new Subject {Id = 1, Name = "Computer Science"},
                    new Subject {Id = 2, Name = "Geography"}
                };
            return subjects;
        }

        #endregion

        #region Game Assets

        [OperationContract]
        public List<FileElement> GetBackgrounds(string path)
        {
            string basePath = Path.Combine(GetDirectory(), @"Repository\Background\");
            path = Path.Combine(basePath, path);

            return GetFiles(path, basePath);
        }

        [OperationContract]
        public List<FileElement> GetImages(string path)
        {
            string basePath = Path.Combine(GetDirectory(), @"Repository\Foreground\");
            path = Path.Combine(basePath, path);

            return GetFiles(path, basePath);
        }

        [OperationContract]
        public List<FileElement> GetCharacters(string path)
        {
            string basePath = Path.Combine(GetDirectory(), @"Repository\Characters\");
            path = Path.Combine(basePath, path);

            return GetFiles(path, basePath);
        }

        [OperationContract]
        public byte[] GetImage(string path)
        {
            string basePath = Path.Combine(GetDirectory(), @"Repository\Foreground\");
            path = Path.Combine(basePath, path);

            return LoadImage(path);
        }

        [OperationContract]
        public byte[] GetBackground(string path)
        {
            string basePath = Path.Combine(GetDirectory(), @"Repository\Background\");
            path = Path.Combine(basePath, path);

            return LoadImage(path);
        }

        [OperationContract]
        public byte[] GetCharacter(string path)
        {
            string basePath = Path.Combine(GetDirectory(), @"Repository\Characters\");
            path = Path.Combine(basePath, path);

            return LoadImage(path);
        }

        #endregion

        #region Private methods

        private static string GetDirectory()
        {
            return HttpContext.Current.Server.MapPath(".");
        }

        private List<FileElement> GetFiles(string path, string basePath)
        {
            string[] dirs = Directory.GetDirectories(path);
            IEnumerable<FileElement> dirElements = from dir in dirs
                                                   select new FileElement
                                                       {
                                                           Path = dir.Replace(basePath, ""),
                                                           Name = Path.GetFileName(dir),
                                                           IsDirectory = true
                                                       };

            string[] files = Directory.GetFiles(path);
            IEnumerable<FileElement> fileElements = from file in files
                                                    select new FileElement
                                                        {
                                                            Path = file.Replace(basePath, ""),
                                                            Name = Path.GetFileName(file),
                                                            IsDirectory = false
                                                        };

            List<FileElement> output = dirElements.ToList();
            output.AddRange(fileElements);

            return output;
        }

        private byte[] LoadImage(string path)
        {
            try
            {
                //load it from file
                var bmp = (Bitmap) Image.FromFile(path);
                //if the image was loaded/drawn then add it to the list
                if (bmp != null)
                {
                    var ms = new MemoryStream();
                    bmp.Save(ms, ImageFormat.Png);
                    ms.Position = 0;

                    return ms.ToArray();
                }
            }
            catch
            {
            }

            return null;
        }

        #endregion

        #region File Data Contract

        [DataContract]
        public class FileElement
        {
            [DataMember]
            public string Path { get; set; }

            [DataMember]
            public bool IsDirectory { get; set; }

            [DataMember]
            public string Name { get; set; }
        }

        #endregion
    }
}
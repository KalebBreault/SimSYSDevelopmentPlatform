﻿using System.Windows;

namespace Common
{
    public static class UIElementExtensions
    {
        public static Rect GetBoundingRect(this FrameworkElement element)
        {
            var rect = new Rect();

            rect.X = element.Margin.Left;
            rect.Y = element.Margin.Top;
            rect.Width = element.ActualWidth;
            rect.Height = element.ActualHeight;

            return rect;
        }

        public static bool HitTest(this FrameworkElement element, Point point)
        {
            return element.GetBoundingRect().Contains(point);
        }
    }
}
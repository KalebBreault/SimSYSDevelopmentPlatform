﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using GameWizardModel;

namespace GameWizard.VisibleAssets
{
    public class ButtonUI : VisibleAssetBase
    {
        private ButtonAsset _asset;
        private Button _uIElement;

        #region IVisibleAsset Implementation

        [Browsable(false)]
        public override AssetBase Asset
        {
            get { return _asset; }
            set { _asset = value as ButtonAsset; }
        }

        [Browsable(false)]
        public override FrameworkElement UIElement
        {
            get { return _uIElement; }
            set { _uIElement = value as Button; }
        }

        #endregion

        #region Public Properties

        [Category("Display")]
        public string Label
        {
            get { return Asset.Name; }
            set
            {
                Asset.Name = value;
                _uIElement.Content = value;
            }
        }

        [Category("Display")]
        public Color ForegroundColor
        {
            get { return _asset.ForegroundColor; }
            set
            {
                _asset.ForegroundColor = value;
                _uIElement.Foreground = new SolidColorBrush(value);
            }
        }

        [Category("Display")]
        public Color BackgroundColor
        {
            get { return _asset.BackgroundColor; }
            set
            {
                _asset.BackgroundColor = value;
                _uIElement.Background = new SolidColorBrush(value);
            }
        }

        [Category("Display")]
        public double FontSize
        {
            get { return _asset.FontSize; }
            set
            {
                _asset.FontSize = value;
                _uIElement.FontSize = value > 0 ? value : 10;
            }
        }

        [Category("Display")]
        public string FontFamily
        {
            get { return _asset.FontFamily; }
            set
            {
                _asset.FontFamily = value;
                _uIElement.FontFamily = new FontFamily(value);
            }
        }

        #endregion
    }
}
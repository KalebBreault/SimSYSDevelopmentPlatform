﻿using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using GameWizard.GameServiceRef;
using GameWizardModel;

namespace GameWizard.VisibleAssets
{
    public class CharacterUI : VisibleAssetBase
    {
        private CharacterAsset _asset;
        protected Image _uIElement;

        #region IVisibleAsset Implementation

        [Browsable(false)]
        public override AssetBase Asset
        {
            get { return _asset; }
            set { _asset = value as CharacterAsset; }
        }

        [Browsable(false)]
        public override FrameworkElement UIElement
        {
            get { return _uIElement; }
            set { _uIElement = value as Image; }
        }

        #endregion

        #region Public Properties

        [Category("Character Information")]
        public string Type
        {
            get { return _asset.Type; }
            set { _asset.Type = value; }
        }

        [Category("Character Information")]
        public string Title
        {
            get { return _asset.Title; }
            set { _asset.Title = value; }
        }

        [Category("Character Information")]
        public string Skills
        {
            get { return _asset.Skills; }
            set { _asset.Skills = value; }
        }

        [Category("Character Information")]
        public int Experience
        {
            get { return _asset.Experience; }
            set { _asset.Experience = value; }
        }

        [Category("Character Information")]
        public string Communication
        {
            get { return _asset.Communication; }
            set { _asset.Communication = value; }
        }

        [Category("Character Information")]
        public string Leadership
        {
            get { return _asset.Leadership; }
            set { _asset.Leadership = value; }
        }

        [Category("Character Information")]
        public string Teamwork
        {
            get { return _asset.Teamwork; }
            set { _asset.Teamwork = value; }
        }

        //example Good

        [Category("Character Information")]
        public string Demographics
        {
            get { return _asset.Demographics; }
            set { _asset.Demographics = value; }
        }

        //example male, caucasion

        [Category("Character Information")]
        public string Degress
        {
            get { return _asset.Degress; }
            set { _asset.Degress = value; }
        }

        #endregion

        #region Event Handler

        public void GetCharacterDataCompleted(object sender, GetCharacterCompletedEventArgs e)
        {
            if (UIElement != null)
            {
                var bmpImage = new BitmapImage();
                var stream = new MemoryStream(e.Result);
                bmpImage.SetSource(stream);

                _uIElement.Source = bmpImage;
            }
        }

        #endregion
    }

    public class CopyOfCharacterUI : ImageUI
    {
        public void GetCharacterDataCompleted(object sender, GetCharacterCompletedEventArgs e)
        {
            if (UIElement != null)
            {
                var bmpImage = new BitmapImage();
                var stream = new MemoryStream(e.Result);
                bmpImage.SetSource(stream);

                _uIElement.Source = bmpImage;
            }
        }
    }
}
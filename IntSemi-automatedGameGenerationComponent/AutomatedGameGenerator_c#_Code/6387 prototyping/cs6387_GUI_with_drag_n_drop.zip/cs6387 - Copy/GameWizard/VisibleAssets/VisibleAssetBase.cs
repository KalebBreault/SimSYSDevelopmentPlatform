﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Common;
using GameWizard.PropertyGridEditors;
using GameWizardModel;
using SLPropertyGrid;

namespace GameWizard.VisibleAssets
{
    public abstract class VisibleAssetBase : NotifyPropertyChangedBase
    {
        #region Fields

        private Point _currentPoint;
        private bool _resizingLL;
        private bool _resizingLR;
        private bool _resizingUL;
        private bool _resizingUR;

        #endregion

        #region Public Properties

        [System.ComponentModel.Browsable(false)]
        public Rectangle SelectedRect { get; set; }

        [System.ComponentModel.Browsable(false)]
        public Rectangle UpperLeftHandle { get; set; }

        [System.ComponentModel.Browsable(false)]
        public Rectangle UpperRightHandle { get; set; }

        [System.ComponentModel.Browsable(false)]
        public Rectangle LowerLeftHandle { get; set; }

        [System.ComponentModel.Browsable(false)]
        public Rectangle LowerRightHandle { get; set; }

        #endregion

        #region Property Grid Properties

        [Category("Dimensions")]
        public double X
        {
            get { return Asset.X; }
            set
            {
                //here we need to set both the asset's X value and the UIElement's X value
                double width = Asset.Width;
                Asset.X = value;
                Asset.Width = width;
                SetUIElementDimensions();
                NotifyPropertyChanged("X");
            }
        }

        [Category("Dimensions")]
        public double Y
        {
            get { return Asset.Y; }
            set
            {
                //here we need to set both the asset's Y value and the UIElement's Y value
                double height = Asset.Height;
                Asset.Y = value;
                Asset.Height = height;
                SetUIElementDimensions();
                NotifyPropertyChanged("Y");
            }
        }

        [Category("Dimensions")]
        public double Width
        {
            get { return Asset.Width; }
            set
            {
                //here we need to set both the asset's width value and the UIElement's width value
                Asset.Width = value;
                SetUIElementDimensions();
                NotifyPropertyChanged("Width");
            }
        }

        [Category("Dimensions")]
        public double Height
        {
            get { return Asset.Height; }
            set
            {
                //here we need to set both the asset's Height value and the UIElement's height value
                Asset.Height = value;
                SetUIElementDimensions();
                NotifyPropertyChanged("Height");
            }
        }

        [Category("Display")]
        public double Opacity
        {
            get { return Asset.Opacity; }
            set
            {
                Asset.Opacity = value;
                UIElement.Opacity = value;
            }
        }

        [Category("Behaviors")]
        [Editor(typeof (BehaviorEditor))] //custom editor for model type
        public ObservableCollection<BehaviorUI> Behaviors
        {
            get { return GetBehaviorList(); }
            set { }
        }

        #endregion

        #region Constructors

        protected VisibleAssetBase()
        {
            SelectedRect = new Rectangle();
            UpperLeftHandle = new Rectangle();
            UpperRightHandle = new Rectangle();
            LowerLeftHandle = new Rectangle();
            LowerRightHandle = new Rectangle();

            UpperLeftHandle.Stroke =
                UpperRightHandle.Stroke =
                LowerLeftHandle.Stroke =
                LowerRightHandle.Stroke = SelectedRect.Stroke = new SolidColorBrush(Colors.Red);

            UpperLeftHandle.StrokeThickness =
                UpperRightHandle.StrokeThickness =
                LowerLeftHandle.StrokeThickness =
                LowerRightHandle.StrokeThickness =
                SelectedRect.StrokeThickness = 1;

            UpperLeftHandle.Fill =
                UpperRightHandle.Fill =
                LowerLeftHandle.Fill =
                LowerRightHandle.Fill = new SolidColorBrush(Colors.Red);
        }

        #endregion

        #region Public Virtual Properties

        [System.ComponentModel.Browsable(false)]
        public virtual AssetBase Asset
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }

        [System.ComponentModel.Browsable(false)]
        public virtual FrameworkElement UIElement
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }

        #endregion

        #region Public Virtual Methods

        public virtual void SetRect(Point point, double width, double height)
        {
            if (Asset != null)
            {
                Asset.SetRect(point, width, height);
                NotifyPropertyChanged("X");
                NotifyPropertyChanged("Y");
                NotifyPropertyChanged("Width");
                NotifyPropertyChanged("Height");
            }
            SetUIElementDimensions();
        }

        public virtual void SetBottomRight(Point point)
        {
            if (Asset != null)
            {
                Asset.SetLowerRight(point);
                NotifyPropertyChanged("Width");
                NotifyPropertyChanged("Height");
            }
            SetUIElementDimensions();
        }

        public virtual void SetTopLeft(Point point)
        {
            if (Asset != null)
            {
                Asset.SetUpperLeft(point);
                NotifyPropertyChanged("X");
                NotifyPropertyChanged("Y");
            }
            SetUIElementDimensions();
        }

        protected virtual void SetUIElementDimensions()
        {
            if (UIElement != null && Asset != null)
            {
                Rect bounds = Asset.Bounds;
                UIElement.Margin = new Thickness(bounds.X, bounds.Y, 0, 0);

                UIElement.Width = bounds.Width;
                UIElement.Height = bounds.Height;

                SetSelectionRect();
            }
        }

        protected virtual void SetSelectionRect()
        {
            Rect bounds = Asset.Bounds;
            SelectedRect.Margin = new Thickness(bounds.X - 1, bounds.Y - 1, 0, 0);
            SelectedRect.Width = bounds.Width + 2;
            SelectedRect.Height = bounds.Height + 2;

            UpperLeftHandle.Margin = new Thickness(bounds.X - 3, bounds.Y - 3, 0, 0);
            LowerLeftHandle.Margin = new Thickness(bounds.X - 3, bounds.Bottom - 3, 0, 0);
            UpperRightHandle.Margin = new Thickness(bounds.Right - 2, bounds.Y - 3, 0, 0);
            LowerRightHandle.Margin = new Thickness(bounds.Right - 2, bounds.Bottom - 2, 0, 0);

            UpperLeftHandle.Width = UpperLeftHandle.Height =
                                    LowerLeftHandle.Width = LowerLeftHandle.Height =
                                                            UpperRightHandle.Width = UpperRightHandle.Height =
                                                                                     LowerRightHandle.Width =
                                                                                     LowerRightHandle.Height = 5;
        }

        #endregion

        #region public Methods

        public bool MouseDown(Point point)
        {
            Debug.WriteLine("VisibleAssetBase.MouseDown");
            _currentPoint = point;
            _resizingUL = UpperLeftHandle.HitTest(point);
            _resizingLL = LowerLeftHandle.HitTest(point);
            _resizingUR = UpperRightHandle.HitTest(point);
            _resizingLR = LowerRightHandle.HitTest(point);
            return HitTest(point);
        }

        public bool MouseUp(Point point)
        {
            Asset.Normalize();
            //redo the select rects in case they have resized the thing inside out
            SetSelectionRect();
            return false;
        }

        public Cursor MouseMove(Point point, bool leftButtonDown)
        {
            if (leftButtonDown)
            {
                var diff = new Point(point.X - _currentPoint.X, point.Y - _currentPoint.Y);
                if (_resizingUL)
                {
                    Asset.MoveUpperLeft(diff);
                }
                else if (_resizingLL)
                {
                    Asset.MoveLowerLeft(diff);
                }
                else if (_resizingUR)
                {
                    Asset.MoveUpperRight(diff);
                }
                else if (_resizingLR)
                {
                    Asset.MoveLowerRight(diff);
                }
                else
                {
                    Asset.Move(diff);
                }

                NotifyPropertyChanged("X");
                NotifyPropertyChanged("Y");
                NotifyPropertyChanged("Width");
                NotifyPropertyChanged("Height");

                SetUIElementDimensions();
                _currentPoint = point;
            }

            if (UpperLeftHandle.HitTest(point) || LowerRightHandle.HitTest(point))
            {
                return Cursors.SizeNWSE;
            }
            else if (LowerLeftHandle.HitTest(point) || UpperRightHandle.HitTest(point))
            {
                return Cursors.SizeNESW;
            }
            else if (Asset.Bounds.Contains(point))
            {
                return Cursors.Hand;
            }

            return Cursors.Arrow;
        }

        public bool HitTest(Point point)
        {
            return Asset.Bounds.Contains(point) || UpperLeftHandle.HitTest(point) || LowerLeftHandle.HitTest(point) ||
                   UpperRightHandle.HitTest(point) || LowerRightHandle.HitTest(point);
        }

        #endregion

        #region Private Methods

        private ObservableCollection<BehaviorUI> GetBehaviorList()
        {
            var behaviorList = new ObservableCollection<BehaviorUI>();
            foreach (Behavior behavior in Asset.BehaviorList)
            {
                if (behavior is TransitionBehavior)
                {
                    behaviorList.Add(new TransitionBehaviorUI(behavior as TransitionBehavior));
                }
                else if (behavior is VisibilityBehavior)
                {
                    behaviorList.Add(new VisibilityBehaviorUI(behavior as VisibilityBehavior));
                }
                else if (behavior is RewardBehavior)
                {
                    behaviorList.Add(new RewardBehaviorUI(behavior as RewardBehavior));
                }
            }

            behaviorList.CollectionChanged += behaviorList_CollectionChanged;
            return behaviorList;
        }

        private void behaviorList_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == NotifyCollectionChangedAction.Add)
            {
                foreach (object item in e.NewItems)
                {
                    var behaviorUI = item as BehaviorUI;
                    Asset.BehaviorList.Add(behaviorUI.Behavior);
                }
            }
            else if (e.Action == NotifyCollectionChangedAction.Remove)
            {
                foreach (object item in e.OldItems)
                {
                    var behaviorUI = item as BehaviorUI;
                    Asset.BehaviorList.Remove(behaviorUI.Behavior);
                }
            }
        }

        #endregion
    }
}
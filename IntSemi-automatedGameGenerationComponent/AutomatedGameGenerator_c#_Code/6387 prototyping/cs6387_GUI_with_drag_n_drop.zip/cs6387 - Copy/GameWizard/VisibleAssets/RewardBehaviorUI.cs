﻿using System.ComponentModel;
using GameWizardModel;

namespace GameWizard.VisibleAssets
{
    public class RewardBehaviorUI : BehaviorUI
    {
        private readonly RewardBehavior _rewardBehavior;

        public RewardBehaviorUI(RewardBehavior behavior)
            : base(behavior)
        {
            _rewardBehavior = behavior;
        }

        [Category("RewardBehavior")]
        public string Certificates
        {
            get { return _rewardBehavior.Certificates; }
            set { _rewardBehavior.Certificates = value; }
        }

        [Category("RewardBehavior")]
        public string Promotions
        {
            get { return _rewardBehavior.Promotions; }
            set { _rewardBehavior.Promotions = value; }
        }

        [Category("RewardBehavior")]
        public string Trophies
        {
            get { return _rewardBehavior.Trophies; }
            set { _rewardBehavior.Trophies = value; }
        }

        [Category("RewardBehavior")]
        public int Points
        {
            get { return _rewardBehavior.Points; }
            set { _rewardBehavior.Points = value; }
        }
    }
}
﻿using System.ComponentModel;
using GameWizardModel;
using SLPropertyGrid;

namespace GameWizard.VisibleAssets
{
    public class BehaviorUI
    {
        public BehaviorUI(Behavior behavior)
        {
            Behavior = behavior;
        }

        [System.ComponentModel.Browsable(false)]
        public Behavior Behavior { get; set; }


        [Category("Behavior")]
        public TriggerTypes Trigger
        {
            get { return Behavior.Trigger; }
            set { Behavior.Trigger = value; }
        }

        [Category("Behavior")]
        [DisplayName("Time until Triggered")]
        [Description("Time in seconds until this behavior is triggered.")]
        public float Time
        {
            get { return Behavior.Time; }
            set { Behavior.Time = value; }
        }

        [System.ComponentModel.Browsable(false)]
        public string DisplayName
        {
            get { return Behavior.DisplayName; }
        }
    }
}
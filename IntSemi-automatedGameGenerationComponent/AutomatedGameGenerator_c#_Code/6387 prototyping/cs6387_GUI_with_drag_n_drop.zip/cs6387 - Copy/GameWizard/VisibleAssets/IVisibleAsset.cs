﻿using System.Windows;
using GameWizardModel;

namespace GameWizard.VisibleAssets
{
    public interface IVisibleAsset
    {
        AssetBase Asset  { get; set; }
        UIElement UIElement { get; set; }

        void SetBottomRight(Point point);
        void SetTopLeft(Point point);
    }
}

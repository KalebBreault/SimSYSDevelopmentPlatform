﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using GameWizardModel;

namespace GameWizard.VisibleAssets
{
    public class InformationBoxUI : VisibleAssetBase
    {
        private InformationBoxAsset _asset;
        private Border _uIElement;

        #region IVisibleAsset Implementation

        [Browsable(false)]
        public override AssetBase Asset
        {
            get { return _asset; }
            set { _asset = value as InformationBoxAsset; }
        }

        [Browsable(false)]
        public override FrameworkElement UIElement
        {
            get { return _uIElement; }
            set { _uIElement = value as Border; }
        }

        #endregion

        #region Public Properties

        [Category("Display")]
        public string Text
        {
            get { return _asset.Name; }
            set
            {
                _asset.Name = value;
                ((TextBlock) _uIElement.Child).Text = value;
            }
        }

        #endregion
    }
}
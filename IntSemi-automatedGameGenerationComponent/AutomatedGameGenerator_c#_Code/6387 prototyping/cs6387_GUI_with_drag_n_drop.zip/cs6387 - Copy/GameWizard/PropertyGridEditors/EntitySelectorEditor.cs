﻿using System;
using System.Collections.Generic;
using System.Windows.Controls;
using GameWizardModel;
using SLPropertyGrid;

namespace GameWizard.PropertyGridEditors
{
    public class EntitySelectorEditor : ValueEditorBase
    {
        private readonly ComboBox Combo;
        private readonly Game _game;
        private object _currentValue;

        public EntitySelectorEditor(PropertyGridLabel label, PropertyItem property, object data)
            : base(label, property)
        {
            _game = data as Game;

            Combo = new ComboBox();
            Combo.SelectionChanged += cbo_SelectionChanged;

            var dictionary = new Dictionary<Guid, string>();

            //yes I know I could have done this recursively but I think it is easier to see and understand in an iterative format
            //note also that there are no new assets added while editing the behaviors
            //Question, can reaching a certain Act,Scene, or Screen trigger behaviors?
            foreach (Act act in _game.Acts)
            {
                //dictionary.Add(act.ID, act.Name);
                foreach (AssetBase asset in act.Assets)
                {
                    dictionary.Add(asset.ID, asset.Name);
                }
                foreach (Scene scene in act.Scenes)
                {
                    //dictionary.Add(scene.ID, scene.Name);
                    foreach (AssetBase asset in scene.Assets)
                    {
                        dictionary.Add(asset.ID, asset.Name);
                    }
                    foreach (Screen screen in scene.Screens)
                    {
                        //dictionary.Add(screen.ID, screen.Name);
                        foreach (AssetBase asset in screen.Assets)
                        {
                            dictionary.Add(asset.ID, asset.Name);
                        }
                    }
                }
            }

            Combo.ItemsSource = dictionary;
            Combo.DisplayMemberPath = "Value";
            Combo.SelectedValuePath = "Key";
            Combo.SelectedValue = (Guid) (Property.Value);
            Content = Combo;
        }

        private void cbo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var temp = (KeyValuePair<Guid, string>) ((sender as ComboBox).SelectedItem);

            Property.Value = temp.Key;
        }
    }
}
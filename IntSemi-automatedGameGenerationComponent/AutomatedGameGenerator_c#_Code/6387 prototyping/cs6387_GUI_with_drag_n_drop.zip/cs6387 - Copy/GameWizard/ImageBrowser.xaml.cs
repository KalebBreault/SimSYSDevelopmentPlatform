﻿using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using GameWizard.GameServiceRef;

namespace GameWizard
{
    public partial class ImageBrowser : ChildWindow
    {
        public enum ImageTypes
        {
            Background,
            Foreground,
            Character
        }

        private readonly GameServiceClient _client;
        private readonly ImageTypes _imageType;
        private string _currentPath = "";
        private ObservableCollection<GameServiceFileElement> _files;
        private byte[] _imageData;

        public ImageBrowser(ImageTypes imageType)
        {
            InitializeComponent();

            _imageType = imageType;

            DataContext = this;

            _client = new GameServiceClient();
            _client.GetBackgroundsCompleted += client_GetBackgroundsCompleted;
            _client.GetBackgroundCompleted += client_GetBackgroundCompleted;

            _client.GetCharacterCompleted += _client_GetCharacterCompleted;
            _client.GetCharactersCompleted += _client_GetCharactersCompleted;

            _client.GetImagesCompleted += client_GetImagesCompleted;
            _client.GetImageCompleted += client_GetImageCompleted;
            switch (_imageType)
            {
                case ImageTypes.Background:
                    _client.GetBackgroundsAsync("");
                    break;
                case ImageTypes.Foreground:
                    _client.GetImagesAsync("");
                    break;
                case ImageTypes.Character:
                    _client.GetCharactersAsync("");
                    break;
            }
        }

        public string SelectedItem { get; set; }

        public byte[] ImageData
        {
            get { return _imageData; }
        }

        private void _client_GetCharactersCompleted(object sender, GetCharactersCompletedEventArgs e)
        {
            PopulateList(e.Result);
        }

        private void _client_GetCharacterCompleted(object sender, GetCharacterCompletedEventArgs e)
        {
            DisplayImage(e.Result);
        }

        private void client_GetImageCompleted(object sender, GetImageCompletedEventArgs e)
        {
            DisplayImage(e.Result);
        }

        private void client_GetImagesCompleted(object sender, GetImagesCompletedEventArgs e)
        {
            PopulateList(e.Result);
        }

        private void client_GetBackgroundCompleted(object sender, GetBackgroundCompletedEventArgs e)
        {
            DisplayImage(e.Result);
        }

        private void client_GetBackgroundsCompleted(object sender, GetBackgroundsCompletedEventArgs e)
        {
            PopulateList(e.Result);
        }

        private void DisplayImage(byte[] imageData)
        {
            if (imageData != null)
            {
                _imageData = imageData;
                var image = new BitmapImage();
                var stream = new MemoryStream(imageData);
                image.SetSource(stream);

                Preview.Source = image;
            }
        }

        private void PopulateList(ObservableCollection<GameServiceFileElement> files)
        {
            _files = files;

            FileListBox.ItemsSource = null;
            FileListBox.ItemsSource = _files;
        }

        private void FileListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var item = FileListBox.SelectedItem as GameServiceFileElement;
            if (item != null && item.IsDirectory == false)
            {
                switch (_imageType)
                {
                    case ImageTypes.Background:
                        _client.GetBackgroundAsync(item.Path);
                        break;
                    case ImageTypes.Foreground:
                        _client.GetImageAsync(item.Path);
                        break;
                    case ImageTypes.Character:
                        _client.GetCharacterAsync(item.Path);
                        break;
                }
            }
            else
            {
                Preview.Source = null;
            }
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            if (SelectItem())
            {
                DialogResult = true;
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void uxBackButton_Click(object sender, RoutedEventArgs e)
        {
            int index = _currentPath.LastIndexOf(@"\");
            _currentPath = index > 0 ? _currentPath.Substring(0, index) : string.Empty;

            switch (_imageType)
            {
                case ImageTypes.Background:
                    _client.GetBackgroundsAsync(_currentPath);
                    break;
                case ImageTypes.Foreground:
                    _client.GetImagesAsync(_currentPath);
                    break;
                case ImageTypes.Character:
                    _client.GetCharactersAsync(_currentPath);
                    break;
            }
        }

        private bool SelectItem()
        {
            var item = FileListBox.SelectedItem as GameServiceFileElement;
            if (item == null)
            {
                return false;
            }

            if (item.IsDirectory)
            {
                _currentPath = item.Path;
                switch (_imageType)
                {
                    case ImageTypes.Background:
                        _client.GetBackgroundsAsync(item.Path);
                        break;
                    case ImageTypes.Foreground:
                        _client.GetImagesAsync(item.Path);
                        break;
                    case ImageTypes.Character:
                        _client.GetCharactersAsync(item.Path);
                        break;
                }
                return false;
            }

            SelectedItem = item.Path;

            return true;
        }
    }
}
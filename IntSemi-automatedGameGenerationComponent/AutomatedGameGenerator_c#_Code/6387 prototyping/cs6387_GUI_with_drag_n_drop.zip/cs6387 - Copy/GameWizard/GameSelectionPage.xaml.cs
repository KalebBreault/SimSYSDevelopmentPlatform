﻿using System.Windows.Controls;
using GameWizard.ViewModel;

namespace GameWizard
{
    public partial class GameSelectionPage : UserControl
    {
        public GameSelectionPage(GameSelectionVM dataContext)
        {
            InitializeComponent();

            DataContext = dataContext;
        }
    }
}
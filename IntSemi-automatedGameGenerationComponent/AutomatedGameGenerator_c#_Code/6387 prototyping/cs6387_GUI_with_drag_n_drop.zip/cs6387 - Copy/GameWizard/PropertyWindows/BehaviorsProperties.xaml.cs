﻿using System;
using System.Collections;
using System.Windows;
using System.Windows.Controls;
using GameWizard.ViewModel;

namespace GameWizard.PropertyWindows
{
    public partial class BehaviorProperties : ChildWindow
    {
        private readonly Type collectionType;

        public BehaviorProperties(IList target, BehaviorPropertiesVM dataContext)
        {
            object styleObj = Application.Current.Resources["collectionEditorChildWindowStyle"];
            if (null != styleObj)
            {
                var style = styleObj as Style;
                if (null != style)
                    Style = style;
            }
            //set datacontext
            DataContext = dataContext;

            InitializeComponent();

            collectionType = target.GetType().GetProperty("Item").PropertyType;

            Title = collectionType.Name + " Behavior Editor";

            dataContext.SetList(target);

            CollectionListBox.ItemsSource = target;
            if (target.Count > 0)
                CollectionListBox.SelectedItem = target[0];
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
        }

        //TODO: Move to ViewModel
        private void CollectionListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
            {
                PropertyGrid.SelectedObject = e.AddedItems[0];
                //because of this we should probably put this in the viewmodel (because I don't want the view having to know the type of the viewmodel)
                ((BehaviorPropertiesVM) DataContext).TargetListSelectedItem = e.AddedItems[0];
                //make sure the veiwmodel knows what is selected for removing things                
            }
            else
                PropertyGrid.SelectedObject = null;
        }

        /// <summary>
        ///     just a local handler for this because this is handled by the superclass and not our viewmodel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
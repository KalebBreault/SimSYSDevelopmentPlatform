﻿using System.Windows;
using System.Windows.Controls;
using GameWizard.ViewModel;

namespace GameWizard.PropertyWindows
{
    public partial class TransitionTargetSelector : ChildWindow
    {
        public TransitionTargetSelector(TransitionTargetSelectorVM dataContext)
        {
            InitializeComponent();

            DataContext = dataContext;
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
﻿namespace GameWizardModel
{
    public class Position
    {
        public float Scale;
        public double X { get; set; }
        public double Y { get; set; }
        public double X2 { get; set; }
        public double Y2 { get; set; }
    }
}
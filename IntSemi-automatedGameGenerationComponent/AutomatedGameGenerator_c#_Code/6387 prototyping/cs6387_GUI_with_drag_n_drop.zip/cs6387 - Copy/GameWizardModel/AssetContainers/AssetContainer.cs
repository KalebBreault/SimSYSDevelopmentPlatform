﻿using System.Collections.ObjectModel;

namespace GameWizardModel
{
    //This is the base class for act/scene/screen. This way the UI does not have to distinguish between them
    //If an attribute does not apply to a child item, it will simply be null
    public class AssetContainer : GameBase
    {
        protected string _background;

        public AssetContainer()
        {
            Assets = new ObservableCollection<AssetBase>();
        }

        public ObservableCollection<AssetBase> Assets { get; set; }

        public virtual string Background
        {
            get { return _background; }
            set
            {
                _background = value;
                NotifyPropertyChanged("Background");
            }
        }
    }
}
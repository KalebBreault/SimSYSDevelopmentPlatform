﻿namespace GameWizardModel
{
    public class Screen : AssetContainer
    {
    }
}
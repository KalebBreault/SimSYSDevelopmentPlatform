﻿namespace GameWizardModel
{
    public class AnswerAsset : AssetBase
    {
        public AnswerAsset(string answerCaption, bool bIsCorrect = false)
        {
            this.bIsCorrect = bIsCorrect;
            AnswerResponse = answerCaption;
        }

        public string AnswerResponse { get; set; }
        public bool bIsCorrect { get; set; }
    }
}
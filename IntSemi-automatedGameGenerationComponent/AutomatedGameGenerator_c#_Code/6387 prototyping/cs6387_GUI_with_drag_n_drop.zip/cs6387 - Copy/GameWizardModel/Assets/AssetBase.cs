﻿using System.Windows;
using System.Xml.Serialization;
#if SILVERLIGHT

#else

#endif

namespace GameWizardModel
{
    /// <summary>
    ///     Asset seperates the game assets from the structure elements that extend gameBase (i.e. seperates buttons and infoboxes from screens and acts)
    /// </summary>
    [XmlInclude(typeof (ImageAsset))]
    [XmlInclude(typeof (InformationBoxAsset))]
    [XmlInclude(typeof (CharacterAsset))]
    [XmlInclude(typeof (ButtonAsset))]
    [XmlRoot("Prop")]
    public class AssetBase : GameBase
    {
        #region Private Fields

        private Position _position;

        #endregion

        #region Public Properties

        public double Opacity { get; set; }

        public double X
        {
            get { return _position.X; }
            set { _position.X = value; }
        }

        public double Y
        {
            get { return _position.Y; }
            set { _position.Y = value; }
        }

        public double X2
        {
            get { return _position.X2; }
            set { _position.X2 = value; }
        }

        public double Y2
        {
            get { return _position.Y2; }
            set { _position.Y2 = value; }
        }

        public double Width
        {
            get { return _position.X2 - _position.X; }
            set { _position.X2 = _position.X + value; }
        }

        public double Height
        {
            get { return _position.Y2 - _position.Y; }
            set { _position.Y2 = _position.Y + value; }
        }

        public Rect Bounds
        {
            get { return NormalizedRect(); }
        }

        #endregion

        #region Construtors

        public AssetBase()
        {
            _position = new Position();
            Opacity = 1;
        }

        #endregion

        #region Public Methods

        public void Move(Point distance)
        {
            X += distance.X;
            Y += distance.Y;
            X2 += distance.X;
            Y2 += distance.Y;
        }

        public void MoveUpperLeft(Point distance)
        {
            X += distance.X;
            Y += distance.Y;
        }

        public void MoveLowerLeft(Point distance)
        {
            X += distance.X;
            Y2 += distance.Y;
        }

        public void MoveUpperRight(Point distance)
        {
            X2 += distance.X;
            Y += distance.Y;
        }

        public void MoveLowerRight(Point distance)
        {
            X2 += distance.X;
            Y2 += distance.Y;
        }

        public void SetUpperLeft(Point point)
        {
            X = point.X;
            Y = point.Y;
        }

        public void SetLowerRight(Point point)
        {
            X2 = point.X;
            Y2 = point.Y;
        }

        public void SetRect(Point point, double width, double height)
        {
            X = point.X;
            Y = point.Y;
            X2 = point.X + width;
            Y2 = point.Y + height;
        }

        public void Normalize()
        {
            if (Width < 0)
            {
                double temp = X;
                X = X2;
                X2 = temp;
            }
            if (Height < 0)
            {
                double temp = Y;
                Y = Y2;
                Y2 = temp;
            }
        }

        #endregion

        #region Private Methods

        private Rect NormalizedRect()
        {
            double x = X;
            double y = Y;
            double x2 = X2;
            double y2 = Y2;

            if (x > x2)
            {
                double temp = x;
                x = x2;
                x2 = temp;
            }
            if (y > y2)
            {
                double temp = y;
                y = y2;
                y2 = temp;
            }

            return new Rect(x, y, x2 - x, y2 - y);
        }

        #endregion
    }
}
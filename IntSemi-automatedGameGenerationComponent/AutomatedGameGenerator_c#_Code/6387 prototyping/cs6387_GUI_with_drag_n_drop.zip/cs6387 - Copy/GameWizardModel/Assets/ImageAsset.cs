﻿namespace GameWizardModel
{
    public class ImageAsset : AssetBase
    {
        public string DisplayImage { get; set; } //this is just the string reference to the image
    }
}
﻿using System.Windows.Media;

namespace GameWizardModel
{
    public class TextAsset : AssetBase
    {
        #region Public Properties

        public Color BackgroundColor { get; set; }
        public Color ForegroundColor { get; set; }
        public double FontSize { get; set; }
        public string FontFamily { get; set; }

        #endregion

        #region Construtors

        public TextAsset()
        {
            BackgroundColor = Colors.Yellow;
            ForegroundColor = Colors.Black;
            FontSize = 15;
            FontFamily = "Comic Sans MS";
        }

        #endregion
    }
}
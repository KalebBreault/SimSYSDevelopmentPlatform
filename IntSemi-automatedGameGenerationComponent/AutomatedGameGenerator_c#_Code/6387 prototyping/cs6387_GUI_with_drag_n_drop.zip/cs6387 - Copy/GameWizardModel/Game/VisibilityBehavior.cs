﻿using System;

namespace GameWizardModel
{
    public class VisibilityBehavior : Behavior
    {
        public VisibilityBehavior()
        {
            DisplayName = "Visiblity Behavior";
        }

        public Guid EntityID { get; set; } //which Entity to change

        public VisibilityModifier NewVisiblity { get; set; }
        //bad name but hard to come up with a question name for this
    }
}
﻿using System;
using System.ComponentModel;

namespace GameWizardModel
{
    public class TransitionBehavior : Behavior
    {
        public TransitionBehavior()
        {
            DisplayName = "Transition Behavior";
        }

        [Category("TransitionBehavior")]
        public Guid TransitionID { get; set; }

        //which screen to go to next

        [Category("TransitionBehavior")]
        public Transition Transition { get; set; }

        //can be null if the behavior just sets an action that doesn't have to do with screen transition
    }
}
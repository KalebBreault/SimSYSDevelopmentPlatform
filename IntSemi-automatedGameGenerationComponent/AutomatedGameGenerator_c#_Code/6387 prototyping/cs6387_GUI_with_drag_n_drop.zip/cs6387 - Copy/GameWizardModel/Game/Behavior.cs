﻿using System.Windows;
using System.Xml.Serialization;

namespace GameWizardModel
{
    [XmlInclude(typeof(TransitionBehavior))]
    [XmlInclude(typeof(RewardBehavior))]
    [XmlInclude(typeof(EndGameBehavior))]
    [XmlInclude(typeof(VisibilityBehavior))]
    public class Behavior
    {        
        public TriggerTypes Trigger { get; set; } //what triggers this behavior (example "None", "Click")
        public float Time { get; set; }
        public string DisplayName { get; set; }
    }
}
﻿namespace GameWizardModel
{
    public class EndGameBehavior : Behavior
    {
        public EndGameBehavior()
        {
            DisplayName = "End Game Behavior";
        }
    }
}
﻿namespace GameWizardModel
{
    public class QuizGameType : GameType
    {
    }
}
﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Common;

namespace GameWizardModel
{
    public class GameBase : NotifyPropertyChangedBase
    {
        private string _name;

        [ReadOnly(true)]
        public Guid ID { get; set; }

        public string Name
        {
            get { return _name; }
            set
            {
                _name = value;
                //This is a hack, should not use this or NotifyPropertyChangedBase
                NotifyPropertyChanged("Name");
            }
        }

        [Browsable(false)] //make sure this is not seen as it is expossed through visibleAsset
        public ObservableCollection<Behavior> BehaviorList { get; set; }

        public GameBase()
        {
            BehaviorList = new ObservableCollection<Behavior>();
            ID = Guid.NewGuid();
        }
    }
}
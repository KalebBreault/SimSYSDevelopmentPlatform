﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SLPropertyGrid
{
    public class CollectionValueEditor : ValueEditorBase
    {
        private readonly Button button;
        private readonly Grid panel;
        private readonly TextBox txt;

        public CollectionValueEditor(PropertyGridLabel label, PropertyItem property)
            : base(label, property)
        {
            property.PropertyChanged += property_PropertyChanged;
            property.ValueError += property_ValueError;

            panel = new Grid();
            panel.ColumnDefinitions.Add(new ColumnDefinition());
            panel.ColumnDefinitions.Add(new ColumnDefinition());
            panel.Height = 20;
            Content = panel;

            txt = new TextBox();
            //txt.Height = 20;
            //if (null != property.Value)
            //    txt.Text = property.Value.ToString();
            txt.Text = "";
            txt.Text = "Click Button to Edit";
            txt.IsReadOnly = true;
            txt.Foreground = Property.CanWrite ? new SolidColorBrush(Colors.Black) : new SolidColorBrush(Colors.Gray);
            txt.Background = new SolidColorBrush(Colors.White);
            txt.BorderThickness = new Thickness(0);
            txt.Margin = new Thickness(0);
            txt.Padding = new Thickness(2);
            txt.SetValue(Grid.ColumnProperty, 0);
            panel.Children.Add(txt);

            if (null != property.Value)
            {
                //button = new Button() { Content = "Click to Edit" };
                button = new Button {Content = "..."};
                button.Click += button_Click;
                button.Margin = new Thickness(1);
                button.SetValue(Grid.ColumnProperty, 1);
                panel.Children.Add(button);
                panel.ColumnDefinitions[1].Width = new GridLength(20);
            }
            else
                Grid.SetColumnSpan(txt, 2);

            GotFocus += StringValueEditor_GotFocus;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (Property.Value != null)
            {
                var child = new CollectionEditorChildWindow((IList) Property.Value);
                child.Closed += child_Closed;
                child.Show();
            }
        }

        private void child_Closed(object sender, EventArgs e)
        {
            txt.Text = Property.Value.ToString();
        }

        private void property_ValueError(object sender, ExceptionEventArgs e)
        {
            MessageBox.Show(e.EventException.Message);
        }

        private void property_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Value")
            {
                if (null != Property.Value)
                    txt.Text = Property.Value.ToString();
                else
                    txt.Text = string.Empty;
            }

            if (e.PropertyName == "CanWrite")
            {
                txt.Foreground = Property.CanWrite
                                     ? new SolidColorBrush(Colors.Black)
                                     : new SolidColorBrush(Colors.Gray);
            }
        }

        private void StringValueEditor_GotFocus(object sender, RoutedEventArgs e)
        {
            if (button != null)
                button.Focus();
        }
    }
}
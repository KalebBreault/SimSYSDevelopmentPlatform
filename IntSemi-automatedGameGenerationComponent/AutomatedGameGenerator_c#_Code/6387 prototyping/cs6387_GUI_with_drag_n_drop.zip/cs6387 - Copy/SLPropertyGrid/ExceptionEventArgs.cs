﻿using System;

namespace SLPropertyGrid
{

    #region Using Directives

    #endregion

    #region ExceptionEventArgs

    /// <summary>
    ///     ExceptionEventArgs
    /// </summary>
    public class ExceptionEventArgs : EventArgs
    {
        /// <summary>
        ///     Constructor
        /// </summary>
        /// <param name="eventException">The Exception</param>
        public ExceptionEventArgs(Exception eventException)
        {
            EventException = eventException;
        }

        /// <summary>
        ///     Gets or sets the Exception
        /// </summary>
        public Exception EventException { get; set; }
    }

    #endregion
}
﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SLPropertyGrid
{
    public partial class MultilineStringEditorChildWindow : ChildWindow
    {
        private readonly PropertyItem property;

        public MultilineStringEditorChildWindow(PropertyItem property)
        {
            InitializeComponent();

            this.property = property;
            var value = property.Value as String;
            if (value != null)
                MainTextBox.Text = value;

            Title = "Edit " + property.Name;
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;

            property.Value = MainTextBox.Text;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
﻿namespace SLPropertyGrid
{
    public interface IPropertyWindowDataProvider
    {
        object GetDataFor(PropertyItem propertyItem);
    }
}
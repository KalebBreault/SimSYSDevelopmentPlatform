﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SLPropertyGrid
{
    public class NestedObjectValueEditor : ValueEditorBase
    {
        private readonly Button button;
        private readonly Grid panel;
        private readonly TextBox txt;

        public NestedObjectValueEditor(PropertyGridLabel label, PropertyItem property)
            : base(label, property)
        {
            property.PropertyChanged += property_PropertyChanged;
            property.ValueError += property_ValueError;

            panel = new Grid();
            panel.ColumnDefinitions.Add(new ColumnDefinition());
            panel.ColumnDefinitions.Add(new ColumnDefinition());
            panel.Height = 20;
            Content = panel;

            txt = new TextBox();
            //txt.Height = 20;
            if (null != property.Value)
                txt.Text = property.Value.ToString();
            txt.IsReadOnly = true;
            txt.Foreground = Property.CanWrite ? new SolidColorBrush(Colors.Black) : new SolidColorBrush(Colors.Gray);
            txt.BorderThickness = new Thickness(0);
            txt.Margin = new Thickness(0);
            txt.Padding = new Thickness(0);
            txt.VerticalAlignment = VerticalAlignment.Center;
            txt.SetValue(Grid.ColumnProperty, 0);
            if (Property.CanWrite)
                txt.TextChanged += Control_TextChanged;
            panel.Children.Add(txt);

            if (null != property.Value)
            {
                button = new Button {Content = "..."};
                button.Click += button_Click;
                button.Margin = new Thickness(1);
                button.SetValue(Grid.ColumnProperty, 1);
                panel.Children.Add(button);
                panel.ColumnDefinitions[1].Width = new GridLength(20);
            }
            else
                Grid.SetColumnSpan(txt, 2);

            GotFocus += StringValueEditor_GotFocus;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (Property.Value != null)
            {
                var childWindow = new ChildWindow {Title = Property.Value.ToString()};
                childWindow.Content = new PropertyGrid
                    {
                        SelectedObject = Property.Value,
                        MinWidth = 300,
                        MinHeight = 400
                    };
                childWindow.Closed += childWindow_Closed;
                childWindow.Show();
            }
        }

        private void childWindow_Closed(object sender, EventArgs e)
        {
            if (Property.Value != null)
            {
                txt.Text = Property.Value.ToString();
            }
        }

        private void property_ValueError(object sender, ExceptionEventArgs e)
        {
            MessageBox.Show(e.EventException.Message);
        }

        private void property_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Value")
            {
                if (null != Property.Value)
                    txt.Text = Property.Value.ToString();
                else
                    txt.Text = string.Empty;
            }

            if (e.PropertyName == "CanWrite")
            {
                if (!Property.CanWrite)
                    txt.TextChanged -= Control_TextChanged;
                else
                    txt.TextChanged += Control_TextChanged;
                txt.IsReadOnly = !Property.CanWrite;
                txt.Foreground = Property.CanWrite
                                     ? new SolidColorBrush(Colors.Black)
                                     : new SolidColorBrush(Colors.Gray);
            }
        }

        private void StringValueEditor_GotFocus(object sender, RoutedEventArgs e)
        {
            if (button != null)
                button.Focus();
        }

        private void Control_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Property.CanWrite && Property.Value.ToString() != txt.Text)
                Property.Value = txt.Text;
        }
    }
}
﻿using System;

namespace SLPropertyGrid
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class DisplayNameAttribute : Attribute
    {
        public DisplayNameAttribute(string displayName)
        {
            if (string.IsNullOrEmpty(displayName)) throw new ArgumentNullException("displayName");
            DisplayName = displayName;
        }

        public string DisplayName { get; private set; }
    }
}
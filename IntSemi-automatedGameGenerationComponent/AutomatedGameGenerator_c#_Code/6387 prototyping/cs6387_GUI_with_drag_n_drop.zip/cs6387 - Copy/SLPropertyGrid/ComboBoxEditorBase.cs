﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SLPropertyGrid
{

    #region Using Directives

    #endregion

    #region ComboBoxEditorBase

    /// <summary>
    ///     An editor for a Boolean Type
    /// </summary>
    public abstract class ComboBoxEditorBase : ValueEditorBase
    {
        #region Fields

        private readonly StackPanel pnl;
        protected ComboBox cbo;
        protected object currentValue;
        private bool showingCBO;
        protected TextBox txt;

        #endregion

        #region Constructors

        /// <summary>
        ///     Constructor
        /// </summary>
        /// <param name="label"></param>
        /// <param name="property"></param>
        public ComboBoxEditorBase(PropertyGridLabel label, PropertyItem property)
            : base(label, property)
        {
            currentValue = property.Value;
            property.PropertyChanged += property_PropertyChanged;
            property.ValueError += property_ValueError;

            cbo = new ComboBox();
            cbo.Visibility = Visibility.Collapsed;
            cbo.Margin = new Thickness(0);
            cbo.Padding = new Thickness(2);
            cbo.VerticalAlignment = VerticalAlignment.Center;
            cbo.HorizontalAlignment = HorizontalAlignment.Stretch;
            cbo.DropDownOpened += cbo_DropDownOpened;
            cbo.LostFocus += cbo_LostFocus;
            cbo.Background = new SolidColorBrush(Colors.White);
            cbo.Foreground = Property.CanWrite ? new SolidColorBrush(Colors.Black) : new SolidColorBrush(Colors.Gray);

            InitializeCombo();

            pnl = new StackPanel();
            pnl.Children.Add(cbo);

            ShowTextBox();

            Content = pnl;
        }

        #endregion

        #region Overrides

        /// <summary>
        /// </summary>
        /// <param name="e"></param>
        protected override void OnGotFocus(RoutedEventArgs e)
        {
            if (showingCBO)
                return;

            base.OnGotFocus(e);

            if (Property.CanWrite)
                ShowComboBox();
        }

        /// <summary>
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLostFocus(RoutedEventArgs e)
        {
            if (cbo.IsDropDownOpen)
                return;

            base.OnLostFocus(e);
        }

        #endregion

        #region Methods

        private void ShowComboBox()
        {
            if (null == txt)
                return;

            cbo.Visibility = Visibility.Visible;
            cbo.Focus();

            #region Sync current value

            cbo.SelectionChanged -= cbo_SelectionChanged;
            for (int i = 0; i < cbo.Items.Count; i++)
            {
                object val = cbo.Items[i];
                if (val.Equals(currentValue) || val.ToString() == currentValue.ToString())
                {
                    cbo.SelectedIndex = i;
                    break;
                }
            }
            cbo.SelectionChanged += cbo_SelectionChanged;

            #endregion

            txt.Visibility = Visibility.Collapsed;
            pnl.Children.Remove(txt);
            txt = null;
        }

        private void ShowTextBox()
        {
            if (null != txt)
                return;

            txt = new TextBox();
            txt.Height = 20;
            txt.BorderThickness = new Thickness(0);
            txt.Margin = new Thickness(0);
            txt.Padding = new Thickness(2);
            txt.VerticalAlignment = VerticalAlignment.Center;
            txt.HorizontalAlignment = HorizontalAlignment.Stretch;
            if (currentValue != null)
                txt.Text = currentValue.ToString();
            else
                txt.Text = "";
            txt.IsReadOnly = !Property.CanWrite;
            txt.Foreground = Property.CanWrite ? new SolidColorBrush(Colors.Black) : new SolidColorBrush(Colors.Gray);
            //txt.Text = currentValue.ToString(); why were they doing this twice
            pnl.Children.Add(txt);

            cbo.Visibility = Visibility.Collapsed;
            showingCBO = false;
        }

        protected virtual void LoadItems(IEnumerable<object> items)
        {
            foreach (object item in items)
                cbo.Items.Add(item.ToString());
        }

        #endregion

        #region Abstract

        /// <summary>
        ///     Initalize the combo box by calling LoadItems passing the list of items for the combobox
        /// </summary>
        public abstract void InitializeCombo();

        #endregion

        #region Event Handlers

        private void property_ValueError(object sender, ExceptionEventArgs e)
        {
            MessageBox.Show(e.EventException.Message);
        }

        private void property_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Value")
                currentValue = Property.Value;

            if (e.PropertyName == "CanWrite")
            {
                if (!Property.CanWrite && showingCBO)
                    ShowTextBox();
            }
        }

        private void cbo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentValue = e.AddedItems[0];
            Property.Value = currentValue;
        }

        private void cbo_DropDownOpened(object sender, EventArgs e)
        {
            showingCBO = true;
        }

        private void cbo_LostFocus(object sender, RoutedEventArgs e)
        {
            if (cbo.IsDropDownOpen)
                return;
            ShowTextBox();
        }

        #endregion
    }

    #endregion
}
﻿using System;
using System.Globalization;

namespace SLPropertyGrid.Converters
{
    public class SByteConverter : BaseNumberConverter
    {
        // Methods
        internal override Type TargetType
        {
            get { return typeof (sbyte); }
        }

        internal override object FromString(string value, CultureInfo culture)
        {
            return sbyte.Parse(value, culture);
        }

        internal override object FromString(string value, NumberFormatInfo formatInfo)
        {
            return sbyte.Parse(value, NumberStyles.Integer, formatInfo);
        }

        internal override object FromString(string value, int radix)
        {
            return Convert.ToSByte(value, radix);
        }

        internal override string ToString(object value, NumberFormatInfo formatInfo)
        {
            var num = (sbyte) value;
            return num.ToString("G", formatInfo);
        }

        // Properties
    }
}
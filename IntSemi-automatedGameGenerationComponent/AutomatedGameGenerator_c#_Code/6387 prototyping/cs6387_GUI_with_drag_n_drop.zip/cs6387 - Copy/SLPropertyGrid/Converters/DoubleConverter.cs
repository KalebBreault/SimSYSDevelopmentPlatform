﻿using System;
using System.Globalization;

namespace SLPropertyGrid.Converters
{
    public class DoubleConverter : BaseNumberConverter
    {
        // Methods
        internal override bool AllowHex
        {
            get { return false; }
        }

        internal override Type TargetType
        {
            get { return typeof (double); }
        }

        internal override object FromString(string value, CultureInfo culture)
        {
            return double.Parse(value, culture);
        }

        internal override object FromString(string value, NumberFormatInfo formatInfo)
        {
            return double.Parse(value, NumberStyles.Float, formatInfo);
        }

        internal override object FromString(string value, int radix)
        {
            return Convert.ToDouble(value, CultureInfo.CurrentCulture);
        }

        internal override string ToString(object value, NumberFormatInfo formatInfo)
        {
            var num = (double) value;
            return num.ToString("R", formatInfo);
        }

        // Properties
    }
}
﻿using System.Windows.Controls;

namespace SLPropertyGrid
{
    public class PropertyGridLabel : ContentControl
    {
        // Methods
        public PropertyGridLabel()
        {
            base.DefaultStyleKey = typeof (PropertyGridLabel);
        }
    }
}
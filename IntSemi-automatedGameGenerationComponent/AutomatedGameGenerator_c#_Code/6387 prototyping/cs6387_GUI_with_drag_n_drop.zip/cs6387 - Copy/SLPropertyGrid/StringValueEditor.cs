﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SLPropertyGrid
{
    public class StringValueEditor : ValueEditorBase
    {
        private readonly Button button;
        private readonly TextBox textBox;

        public StringValueEditor(PropertyGridLabel label, PropertyItem property)
            : base(label, property)
        {
            if (property.PropertyType == typeof (Char))
            {
                if ((char) property.Value == '\0')
                    property.Value = "";
            }

            property.PropertyChanged += property_PropertyChanged;
            property.ValueError += property_ValueError;

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.Height = 20;
            Content = grid;

            textBox = new TextBox();
            textBox.Height = 20;
            if (null != property.Value)
                textBox.Text = property.Value.ToString();
            textBox.IsReadOnly = !Property.CanWrite;
            textBox.Foreground = Property.CanWrite
                                     ? new SolidColorBrush(Colors.Black)
                                     : new SolidColorBrush(Colors.Gray);
            textBox.Background = new SolidColorBrush(Colors.White);
            textBox.BorderThickness = new Thickness(0);
            textBox.Margin = new Thickness(0);
            textBox.Padding = new Thickness(2);
            textBox.GotFocus += textBox_GotFocus;
            textBox.AcceptsReturn = true;

            grid.Children.Add(textBox);

            if (Property.CanWrite)
                textBox.TextChanged += Control_TextChanged;

            if (Property.CanWrite && property.PropertyType == typeof (string))
            {
                button = new Button {Content = "..."};
                button.Click += button_Click;
                button.Margin = new Thickness(1);
                button.SetValue(Grid.ColumnProperty, 1);
                grid.Children.Add(button);
                grid.ColumnDefinitions[1].Width = new GridLength(20);
            }
            else
                Grid.SetColumnSpan(textBox, 2);

            GotFocus += StringValueEditor_GotFocus;
        }

        private void StringValueEditor_GotFocus(object sender, RoutedEventArgs e)
        {
            if (button == null || !button.IsFocused)
            {
                textBox.Focus();
            }
        }

        private void textBox_GotFocus(object sender, RoutedEventArgs e)
        {
            textBox.SelectAll();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            new MultilineStringEditorChildWindow(Property).Show();
        }

        private void property_ValueError(object sender, ExceptionEventArgs e)
        {
            textBox.Background = new SolidColorBrush(Colors.Red);
        }

        private void property_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            // clear error background color
            textBox.Background = new SolidColorBrush(Colors.White);

            if (e.PropertyName == "Value")
            {
                if (null != Property.Value)
                {
                    if (textBox.Text != Property.Value.ToString())
                    {
                        textBox.Text = Property.Value.ToString();
                        textBox.SelectionStart = textBox.Text.Length; // move cursor to end
                    }
                }
                else
                    textBox.Text = string.Empty;
            }

            if (e.PropertyName == "CanWrite")
            {
                if (!Property.CanWrite)
                    textBox.TextChanged -= Control_TextChanged;
                else
                    textBox.TextChanged += Control_TextChanged;
                textBox.IsReadOnly = !Property.CanWrite;
                textBox.Foreground = Property.CanWrite
                                         ? new SolidColorBrush(Colors.Black)
                                         : new SolidColorBrush(Colors.Gray);
            }
        }

        private void Control_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Property.CanWrite)
            {
                Property.Value = textBox.Text;
            }
        }
    }
}
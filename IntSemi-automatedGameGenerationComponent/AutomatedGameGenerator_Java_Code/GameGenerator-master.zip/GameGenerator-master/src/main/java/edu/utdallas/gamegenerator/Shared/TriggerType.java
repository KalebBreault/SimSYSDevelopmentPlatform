package edu.utdallas.gamegenerator.Shared;

/**
 * User: clocke
 * Date: 4/11/13
 * Time: 8:34 PM
 */
public enum TriggerType {
    Click;
//    SINGLE_CLICK("Click"),
//    DOUBLE_CLICK("Double Click");
//
//    private String value;
//
//    TriggerType(String value) {
//        this.value = value;
//    }
//
//    public String toString() {
//        return value;
//    }
}

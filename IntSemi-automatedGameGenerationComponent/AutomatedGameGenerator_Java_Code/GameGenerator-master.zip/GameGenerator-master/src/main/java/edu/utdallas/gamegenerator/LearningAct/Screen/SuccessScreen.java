package edu.utdallas.gamegenerator.LearningAct.Screen;

/**
 * User: clocke
 * Date: 2/17/13
 * Time: 4:44 PM
 */
public class SuccessScreen extends BaseScreen {
    @Override
    public ScreenType getType() {
        return ScreenType.SUCCESS;
    }
}

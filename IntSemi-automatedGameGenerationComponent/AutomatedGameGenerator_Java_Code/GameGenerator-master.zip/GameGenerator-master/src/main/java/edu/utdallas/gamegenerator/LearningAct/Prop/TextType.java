package edu.utdallas.gamegenerator.LearningAct.Prop;

/**
 * User: clocke
 * Date: 2/17/13
 * Time: 3:26 PM
 */
public enum TextType {
    PLAYER,
    HERO,
    VILLIAN,
    ALT1,
    ALT2,
    CHALLENGE_DESCRIPTION,
    CHALLENGE_QUESTION;
}

package edu.utdallas.gamegenerator.Shared;

/**
 * User: clocke
 * Date: 3/3/13
 * Time: 8:58 PM
 */
public class Color {
    private int a;
    private int r;
    private int g;
    private int b;

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getR() {
        return r;
    }

    public void setR(int r) {
        this.r = r;
    }

    public int getG() {
        return g;
    }

    public void setG(int g) {
        this.g = g;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }
}
